export interface AssessmentAnswers {
  age?: number;
  educationLevel?: string;
  incomeRange?: string;
  skills?: string[];
  experienceYears?: number;
  internetAccess?: "none" | "limited" | "stable";
  hasDevice?: boolean;
  portfolioItems?: number;
  networkSize?: "small" | "medium" | "large";
  location?: string;
  careerGoals?: string;
  preferredWorkStyle?: string;
}

export interface ScoreBreakdown {
  digitalSkills: number;
  communication: number;
  education: number;
  portfolio: number;
  experience: number;
  marketDemand: number;
  location: number;
  networking: number;
}

export interface ScoreResult {
  total: number;
  breakdown: ScoreBreakdown;
  recommendations: string[];
}

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));

/**
 * Deterministic, explainable rule-based score across 8 categories (0-100 each),
 * combined into a single 0-100 Income Readiness Score. This is intentionally
 * simple and transparent — swap in a trained model later without changing the
 * API contract (POST /assessment always returns { total, breakdown, recommendations }).
 */
export function computeReadinessScore(answers: AssessmentAnswers): ScoreResult {
  const digitalSkills = clamp(
    (answers.skills?.length ?? 0) * 15 + (answers.hasDevice ? 15 : 0)
  );

  const communication = clamp(
    answers.careerGoals && answers.careerGoals.length > 10 ? 65 : 40
  );

  const educationMap: Record<string, number> = {
    none: 20,
    primary: 30,
    secondary: 50,
    nce_ond: 65,
    bsc_hnd: 80,
    msc_plus: 95,
  };
  const education = clamp(educationMap[answers.educationLevel ?? ""] ?? 45);

  const portfolio = clamp((answers.portfolioItems ?? 0) * 20);

  const experience = clamp((answers.experienceYears ?? 0) * 12);

  const marketDemandMap: Record<string, number> = {
    none: 20,
    "10-50k": 40,
    "50-150k": 60,
    "150k+": 80,
  };
  const marketDemand = clamp(marketDemandMap[answers.incomeRange ?? ""] ?? 40);

  const internetMap: Record<string, number> = { none: 15, limited: 50, stable: 90 };
  const location = clamp(internetMap[answers.internetAccess ?? ""] ?? 50);

  const networkMap: Record<string, number> = { small: 30, medium: 60, large: 90 };
  const networking = clamp(networkMap[answers.networkSize ?? ""] ?? 30);

  const breakdown: ScoreBreakdown = {
    digitalSkills,
    communication,
    education,
    portfolio,
    experience,
    marketDemand,
    location,
    networking,
  };

  const total = clamp(
    Object.values(breakdown).reduce((a, b) => a + b, 0) / Object.keys(breakdown).length
  );

  const recommendations: string[] = [];
  if (digitalSkills < 50) recommendations.push("Build 2–3 practical digital skills through short courses.");
  if (portfolio < 40) recommendations.push("Create at least 2 portfolio pieces showing your work.");
  if (networking < 50) recommendations.push("Join a professional community or WhatsApp group in your field.");
  if (experience < 30) recommendations.push("Look for internships, volunteer work, or freelance gigs to build experience.");
  if (location < 40) recommendations.push("Identify a nearby location with more stable internet access for job searching.");

  return { total, breakdown, recommendations };
}
