const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = "claude-sonnet-4-5";

interface AnthropicMessage {
  role: "user" | "assistant";
  content: string;
}

async function callClaude(system: string, messages: AnthropicMessage[]): Promise<string | null> {
  if (!ANTHROPIC_API_KEY) return null;

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 700,
        system,
        messages,
      }),
    });

    if (!res.ok) {
      console.error("Anthropic API error:", res.status, await res.text());
      return null;
    }

    const data = (await res.json()) as { content?: { type: string; text?: string }[] };
    const textBlock = data.content?.find((b) => b.type === "text");
    return textBlock?.text ?? null;
  } catch (err) {
    console.error("Anthropic API request failed:", err);
    return null;
  }
}

const LANGUAGE_NAMES: Record<string, string> = {
  en: "English",
  ha: "Hausa",
  yo: "Yoruba",
  ig: "Igbo",
};

/** AI Mentor chat reply — career, business, financial, and interview coaching. */
export async function getChatReply(
  history: AnthropicMessage[],
  language: string = "en"
): Promise<string> {
  const langName = LANGUAGE_NAMES[language] ?? "English";
  const system = `You are the AI Mentor inside Skill2Income, an economic mobility platform helping Nigerians move from unemployment or underemployment into sustainable income. Reply in ${langName}. Be warm, direct, and practical. Give concrete, Nigeria-relevant advice (naira amounts, local job market realities, NYSC context where relevant). Keep replies under 120 words unless asked for more detail.`;

  const reply = await callClaude(system, history);
  if (reply) return reply;

  // Fallback so the product works end-to-end without an API key configured.
  return "Thanks for sharing that. Here's a practical next step: break your goal into one small action you can complete today, then check back in with me tomorrow on how it went. (Note: connect an ANTHROPIC_API_KEY in .env for full AI-powered coaching.)";
}

/** BusinessAI — generates a structured business plan from an idea + budget. */
export async function generateBusinessPlan(idea: string, budgetNaira: number) {
  const system = `You are BusinessAI inside Skill2Income. Given a business idea and a budget in Nigerian naira, respond ONLY with strict JSON (no markdown, no preamble) matching this shape:
{
  "startupCostBreakdown": [{"label": string, "amountNaira": number}],
  "swot": {"strengths": string, "weaknesses": string, "opportunities": string, "threats": string},
  "businessModelCanvas": {"valueProp": string, "customers": string, "channels": string, "revenue": string},
  "breakEvenMonths": number,
  "riskAnalysis": string
}
All amountNaira values must sum to approximately the given budget.`;

  const reply = await callClaude(system, [
    { role: "user", content: `Idea: ${idea}\nBudget: ₦${budgetNaira.toLocaleString()}` },
  ]);

  if (reply) {
    try {
      return JSON.parse(reply);
    } catch {
      // fall through to rule-based fallback if the model didn't return clean JSON
    }
  }

  // Rule-based fallback (no API key / parse failure) — keeps the endpoint always usable.
  return {
    startupCostBreakdown: [
      { label: "Materials", amountNaira: Math.round(budgetNaira * 0.45) },
      { label: "Tools/equipment", amountNaira: Math.round(budgetNaira * 0.28) },
      { label: "Marketing", amountNaira: Math.round(budgetNaira * 0.17) },
      { label: "Buffer", amountNaira: Math.round(budgetNaira * 0.1) },
    ],
    swot: {
      strengths: "Existing hands-on skill and initial customer interest.",
      weaknesses: "No formal business structure or delivery system yet.",
      opportunities: `Rising local demand around: ${idea}.`,
      threats: "Input cost inflation and seasonal demand swings.",
    },
    businessModelCanvas: {
      valueProp: `Reliable, well-priced offering: ${idea}.`,
      customers: "Local customers reachable via social media and referrals.",
      channels: "Instagram, WhatsApp Business, word-of-mouth.",
      revenue: "Per-order sales, deposit + balance on custom work.",
    },
    breakEvenMonths: 4,
    riskAnalysis:
      "Fallback estimate (no AI key configured) — connect ANTHROPIC_API_KEY for a plan tailored to your specific idea and market.",
  };
}

/** Income Blueprint — recommended path + milestones based on assessment answers. */
export async function generateBlueprintNarrative(
  answersJson: string,
  scoreTotal: number
): Promise<{ recommendedPath: string; monthlyGoals: string[]; riskAnalysis: string }> {
  const system = `You are the career strategist inside Skill2Income. Given a user's assessment answers (JSON) and their Income Readiness Score (0-100), respond ONLY with strict JSON: {"recommendedPath": string, "monthlyGoals": string[4], "riskAnalysis": string}. Keep it realistic for the Nigerian job/informal market.`;

  const reply = await callClaude(system, [
    { role: "user", content: `Answers: ${answersJson}\nScore: ${scoreTotal}` },
  ]);

  if (reply) {
    try {
      return JSON.parse(reply);
    } catch {
      /* fall through */
    }
  }

  return {
    recommendedPath:
      scoreTotal >= 60 ? "Digital Marketing Assistant (employment track)" : "Skilled Trade Formalization (self-employment track)",
    monthlyGoals: [
      "Complete one foundational skills course",
      "Build a 3-piece portfolio",
      "Apply to or pitch 5 opportunities",
      "Track income and expenses weekly",
    ],
    riskAnalysis:
      "Fallback estimate (no AI key configured) — connect ANTHROPIC_API_KEY for a plan tailored to this specific user.",
  };
}
