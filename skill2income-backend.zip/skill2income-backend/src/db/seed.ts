import "dotenv/config";
import "../db"; // applies schema
import { db, get, run } from "../db";
import { id } from "../lib/id";

function seedJobs() {
  const existing = get("SELECT id FROM jobs LIMIT 1");
  if (existing) {
    console.log("Jobs already seeded, skipping.");
    return;
  }

  const jobs = [
    {
      title: "Social Media Assistant",
      employer: "Konga",
      location: "Remote",
      salaryMin: 80000,
      salaryMax: 120000,
      skillsRequired: "social media,canva,copywriting",
      description: "Manage Konga's social media calendar and respond to customer comments.",
      source: "manual",
    },
    {
      title: "Customer Support Rep",
      employer: "Paystack",
      location: "Lagos (Hybrid)",
      salaryMin: 150000,
      salaryMax: 200000,
      skillsRequired: "communication,crm,problem solving",
      description: "First line of support for Paystack merchant queries.",
      source: "manual",
    },
    {
      title: "Data Entry Clerk (NYSC)",
      employer: "Kano State Ministry",
      location: "Kano",
      salaryMin: 33000,
      salaryMax: 45000,
      skillsRequired: "ms excel,attention to detail",
      description: "NYSC placement supporting ministry records digitization.",
      source: "manual",
    },
  ];

  for (const job of jobs) {
    run(
      `INSERT INTO jobs (id, title, employer, location, salary_min, salary_max, skills_required, description, source)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id(),
        job.title,
        job.employer,
        job.location,
        job.salaryMin,
        job.salaryMax,
        job.skillsRequired,
        job.description,
        job.source,
      ]
    );
  }
  console.log(`Seeded ${jobs.length} jobs.`);
}

function seedOpportunities() {
  const existing = get("SELECT id FROM opportunities LIMIT 1");
  if (existing) {
    console.log("Opportunities already seeded, skipping.");
    return;
  }

  const opportunities = [
    {
      type: "nysc",
      title: "NYSC Skill Acquisition & Entrepreneurship Development (SAED)",
      deadline: "2026-09-30",
      link: "https://nysc.gov.ng",
      eligibility: "Current NYSC corps members",
    },
    {
      type: "grant",
      title: "Tony Elumelu Foundation Entrepreneurship Programme",
      deadline: "2027-01-31",
      link: "https://tefconnect.com",
      eligibility: "African entrepreneurs, early-stage business",
    },
    {
      type: "scholarship",
      title: "3MTT AI & Machine Learning Fellowship",
      deadline: "2026-08-15",
      link: "https://3mtt.nitda.gov.ng",
      eligibility: "Nigerian residents, basic digital literacy",
    },
  ];

  for (const o of opportunities) {
    run(
      "INSERT INTO opportunities (id, type, title, deadline, link, eligibility) VALUES (?, ?, ?, ?, ?, ?)",
      [id(), o.type, o.title, o.deadline, o.link, o.eligibility]
    );
  }
  console.log(`Seeded ${opportunities.length} opportunities.`);
}

function seedDemoUser() {
  const existing = get("SELECT id FROM users WHERE phone = ?", ["+2348031234567"]);
  if (existing) {
    console.log("Demo user already seeded, skipping.");
    return;
  }

  const userId = id();
  run("INSERT INTO users (id, phone, auth_provider, role) VALUES (?, ?, 'phone', 'user')", [
    userId,
    "+2348031234567",
  ]);
  run(
    `INSERT INTO user_profiles (id, user_id, age, education_level, state, lga, skills, interests, career_goals, internet_access, preferred_work_style)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      id(),
      userId,
      24,
      "bsc_hnd",
      "Kano State",
      "Nassarawa",
      "social media,canva,customer service",
      "digital marketing,fashion",
      "Land a role that uses my degree, or grow a steady side income.",
      "limited",
      "employment",
    ]
  );
  console.log(`Seeded demo user (phone: +2348031234567, OTP flow only).`);
}

seedJobs();
seedOpportunities();
seedDemoUser();
console.log("Seed complete.");
