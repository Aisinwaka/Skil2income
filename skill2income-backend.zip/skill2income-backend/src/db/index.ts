import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";

const DB_PATH = process.env.DATABASE_FILE || path.join(__dirname, "../../dev.db");
const SCHEMA_PATH = path.join(__dirname, "schema.sql");

export const db = new DatabaseSync(DB_PATH);

// Apply schema idempotently on boot (CREATE TABLE IF NOT EXISTS)
const schemaSql = fs.readFileSync(SCHEMA_PATH, "utf-8");
db.exec(schemaSql);

/** Small helper: run a parameterized SELECT returning all rows. */
export function all<T = any>(sql: string, params: any[] = []): T[] {
  const stmt = db.prepare(sql);
  return stmt.all(...params) as T[];
}

/** Small helper: run a parameterized SELECT returning the first row (or undefined). */
export function get<T = any>(sql: string, params: any[] = []): T | undefined {
  const stmt = db.prepare(sql);
  return stmt.get(...params) as T | undefined;
}

/** Small helper: run an INSERT/UPDATE/DELETE. */
export function run(sql: string, params: any[] = []) {
  const stmt = db.prepare(sql);
  return stmt.run(...params);
}
