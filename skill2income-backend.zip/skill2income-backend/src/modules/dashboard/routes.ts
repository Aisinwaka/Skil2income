import { Router } from "express";
import { get, all } from "../../db";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";

export const dashboardRouter = Router();

dashboardRouter.get(
  "/",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const userId = req.user!.userId;

    const profile = get<{ state: string | null }>(
      "SELECT state FROM user_profiles WHERE user_id = ?",
      [userId]
    );

    const assessment = get<{ id: string; readiness_score: number; score_breakdown: string }>(
      "SELECT id, readiness_score, score_breakdown FROM assessments WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
      [userId]
    );

    const blueprint = assessment
      ? get<{ recommended_path: string; milestones: string; expected_income_range: string }>(
          "SELECT recommended_path, milestones, expected_income_range FROM income_blueprints WHERE assessment_id = ? ORDER BY created_at DESC LIMIT 1",
          [assessment.id]
        )
      : undefined;

    const topJob = get(
      "SELECT id, title, employer, location, salary_min, salary_max FROM jobs ORDER BY created_at DESC LIMIT 1"
    );

    const recentTransactions = all(
      "SELECT type, amount, category, occurred_at FROM transactions WHERE user_id = ? ORDER BY occurred_at DESC LIMIT 5",
      [userId]
    );

    res.json({
      readinessScore: assessment?.readiness_score ?? null,
      scoreBreakdown: assessment?.score_breakdown ? JSON.parse(assessment.score_breakdown) : null,
      location: profile?.state ?? null,
      roadmap: blueprint
        ? {
            recommendedPath: blueprint.recommended_path,
            expectedIncomeRange: blueprint.expected_income_range,
            milestones: blueprint.milestones ? JSON.parse(blueprint.milestones) : [],
          }
        : null,
      recommendedJob: topJob ?? null,
      recentTransactions,
    });
  })
);
