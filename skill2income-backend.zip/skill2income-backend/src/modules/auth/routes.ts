import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db, get, run, all } from "../../db";
import { id } from "../../lib/id";
import { signToken } from "../../lib/jwt";
import { asyncHandler } from "../../lib/async-handler";
import { ApiError } from "../../middleware/error";
import { requireAuth, AuthedRequest } from "../../middleware/auth";

export const authRouter = Router();

/* ---------------- Phone + OTP ---------------- */

const requestOtpSchema = z.object({ phone: z.string().min(8) });

authRouter.post(
  "/otp/request",
  asyncHandler(async (req, res) => {
    const { phone } = requestOtpSchema.parse(req.body);

    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    run("INSERT INTO otp_codes (id, phone, code, expires_at, consumed) VALUES (?, ?, ?, ?, 0)", [
      id(),
      phone,
      code,
      expiresAt,
    ]);

    // In production this would call an SMS provider (e.g. Termii, Africa's Talking).
    console.log(`[OTP] ${phone} -> ${code} (expires ${expiresAt})`);

    res.json({
      message: "OTP sent",
      // Returned only because there's no real SMS provider wired up in this dev build.
      devCode: code,
    });
  })
);

const verifyOtpSchema = z.object({ phone: z.string().min(8), code: z.string().length(6) });

authRouter.post(
  "/otp/verify",
  asyncHandler(async (req, res) => {
    const { phone, code } = verifyOtpSchema.parse(req.body);

    const otp = get<{ id: string; expires_at: string; consumed: number }>(
      "SELECT id, expires_at, consumed FROM otp_codes WHERE phone = ? AND code = ? ORDER BY expires_at DESC LIMIT 1",
      [phone, code]
    );

    if (!otp) throw new ApiError(401, "Invalid code");
    if (otp.consumed) throw new ApiError(401, "Code already used");
    if (new Date(otp.expires_at).getTime() < Date.now()) throw new ApiError(401, "Code expired");

    run("UPDATE otp_codes SET consumed = 1 WHERE id = ?", [otp.id]);

    let user = get<{ id: string; role: string }>("SELECT id, role FROM users WHERE phone = ?", [phone]);
    if (!user) {
      const newId = id();
      run(
        "INSERT INTO users (id, phone, auth_provider, role) VALUES (?, ?, 'phone', 'user')",
        [newId, phone]
      );
      run("INSERT INTO user_profiles (id, user_id) VALUES (?, ?)", [id(), newId]);
      user = { id: newId, role: "user" };
    }

    const token = signToken({ userId: user.id, role: user.role });
    res.json({ token });
  })
);

/* ---------------- Email + password ---------------- */

const emailAuthSchema = z.object({ email: z.string().email(), password: z.string().min(6) });

authRouter.post(
  "/register",
  asyncHandler(async (req, res) => {
    const { email, password } = emailAuthSchema.parse(req.body);

    const existing = get("SELECT id FROM users WHERE email = ?", [email]);
    if (existing) throw new ApiError(409, "An account with this email already exists");

    const passwordHash = await bcrypt.hash(password, 10);
    const newId = id();
    run(
      "INSERT INTO users (id, email, password_hash, auth_provider, role) VALUES (?, ?, ?, 'email', 'user')",
      [newId, email, passwordHash]
    );
    run("INSERT INTO user_profiles (id, user_id) VALUES (?, ?)", [id(), newId]);

    const token = signToken({ userId: newId, role: "user" });
    res.status(201).json({ token });
  })
);

authRouter.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { email, password } = emailAuthSchema.parse(req.body);

    const user = get<{ id: string; password_hash: string | null; role: string }>(
      "SELECT id, password_hash, role FROM users WHERE email = ?",
      [email]
    );
    if (!user || !user.password_hash) throw new ApiError(401, "Invalid credentials");

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) throw new ApiError(401, "Invalid credentials");

    const token = signToken({ userId: user.id, role: user.role });
    res.json({ token });
  })
);

/* ---------------- Current user ---------------- */

authRouter.get(
  "/me",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const user = get(
      `SELECT u.id, u.email, u.phone, u.role, p.age, p.education_level, p.state, p.lga,
              p.skills, p.interests, p.career_goals, p.preferred_work_style
       FROM users u LEFT JOIN user_profiles p ON p.user_id = u.id
       WHERE u.id = ?`,
      [req.user!.userId]
    );
    if (!user) throw new ApiError(404, "User not found");
    res.json(user);
  })
);
