import { Router } from "express";
import { z } from "zod";
import { get, run } from "../../db";
import { id } from "../../lib/id";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";
import { getChatReply } from "../../lib/ai";

export const chatRouter = Router();

interface StoredMessage {
  role: "user" | "assistant";
  content: string;
  ts: string;
}

function loadSession(userId: string) {
  let session = get<{ id: string; language: string; messages: string }>(
    "SELECT id, language, messages FROM chat_sessions WHERE user_id = ? ORDER BY updated_at DESC LIMIT 1",
    [userId]
  );
  if (!session) {
    const newId = id();
    run(
      "INSERT INTO chat_sessions (id, user_id, language, messages) VALUES (?, ?, 'en', '[]')",
      [newId, userId]
    );
    session = { id: newId, language: "en", messages: "[]" };
  }
  return session;
}

chatRouter.get(
  "/",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const session = loadSession(req.user!.userId);
    res.json({ language: session.language, messages: JSON.parse(session.messages) as StoredMessage[] });
  })
);

const messageSchema = z.object({
  message: z.string().min(1),
  language: z.enum(["en", "ha", "yo", "ig"]).default("en"),
});

chatRouter.post(
  "/message",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const { message, language } = messageSchema.parse(req.body);
    const userId = req.user!.userId;
    const session = loadSession(userId);

    const history: StoredMessage[] = JSON.parse(session.messages);
    history.push({ role: "user", content: message, ts: new Date().toISOString() });

    const reply = await getChatReply(
      history.map((m) => ({ role: m.role, content: m.content })),
      language
    );

    history.push({ role: "assistant", content: reply, ts: new Date().toISOString() });

    run("UPDATE chat_sessions SET messages = ?, language = ?, updated_at = datetime('now') WHERE id = ?", [
      JSON.stringify(history),
      language,
      session.id,
    ]);

    res.json({ reply });
  })
);
