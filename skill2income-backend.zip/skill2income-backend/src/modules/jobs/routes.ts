import { Router } from "express";
import { z } from "zod";
import { get, all, run } from "../../db";
import { id } from "../../lib/id";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";
import { ApiError } from "../../middleware/error";

export const jobsRouter = Router();

jobsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const { search, location } = req.query as { search?: string; location?: string };

    let sql = "SELECT * FROM jobs WHERE 1=1";
    const params: any[] = [];

    if (search) {
      sql += " AND (title LIKE ? OR employer LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (location) {
      sql += " AND location LIKE ?";
      params.push(`%${location}%`);
    }
    sql += " ORDER BY created_at DESC";

    const jobs = all(sql, params);
    res.json(jobs);
  })
);

const applySchema = z.object({ status: z.enum(["saved", "applied"]).default("saved") });

jobsRouter.post(
  "/:jobId/apply",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const { status } = applySchema.parse(req.body ?? {});
    const job = get("SELECT id FROM jobs WHERE id = ?", [req.params.jobId]);
    if (!job) throw new ApiError(404, "Job not found");

    const existing = get<{ id: string }>(
      "SELECT id FROM applications WHERE user_id = ? AND job_id = ?",
      [req.user!.userId, req.params.jobId]
    );

    // naive demo match score — a real implementation would compare skill vectors
    const matchPercentage = Math.floor(50 + Math.random() * 45);

    if (existing) {
      run("UPDATE applications SET status = ?, applied_at = datetime('now') WHERE id = ?", [
        status,
        existing.id,
      ]);
    } else {
      run(
        `INSERT INTO applications (id, user_id, job_id, status, match_percentage, applied_at)
         VALUES (?, ?, ?, ?, ?, datetime('now'))`,
        [id(), req.user!.userId, req.params.jobId, status, matchPercentage]
      );
    }

    res.json({ ok: true, status, matchPercentage });
  })
);

jobsRouter.get(
  "/applications/mine",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const applications = all(
      `SELECT a.id, a.status, a.match_percentage, a.applied_at, j.title, j.employer, j.location
       FROM applications a JOIN jobs j ON j.id = a.job_id
       WHERE a.user_id = ? ORDER BY a.created_at DESC`,
      [req.user!.userId]
    );
    res.json(applications);
  })
);
