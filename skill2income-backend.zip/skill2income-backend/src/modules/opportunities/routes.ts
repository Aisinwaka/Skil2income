import { Router } from "express";
import { all } from "../../db";
import { asyncHandler } from "../../lib/async-handler";

export const opportunitiesRouter = Router();

opportunitiesRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const { type } = req.query as { type?: string };
    const opportunities = type
      ? all("SELECT * FROM opportunities WHERE type = ? ORDER BY deadline ASC", [type])
      : all("SELECT * FROM opportunities ORDER BY deadline ASC");
    res.json(opportunities);
  })
);
