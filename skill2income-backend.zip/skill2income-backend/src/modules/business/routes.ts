import { Router } from "express";
import { z } from "zod";
import { all, run } from "../../db";
import { id } from "../../lib/id";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";
import { generateBusinessPlan } from "../../lib/ai";

export const businessRouter = Router();

const generateSchema = z.object({
  idea: z.string().min(5),
  budgetNaira: z.number().positive(),
});

businessRouter.post(
  "/generate",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const { idea, budgetNaira } = generateSchema.parse(req.body);

    const plan = await generateBusinessPlan(idea, budgetNaira);

    const businessId = id();
    run(
      `INSERT INTO businesses (id, user_id, idea, business_plan, startup_cost, break_even_months)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [businessId, req.user!.userId, idea, JSON.stringify(plan), budgetNaira, plan.breakEvenMonths ?? null]
    );

    res.status(201).json({ businessId, idea, budgetNaira, plan });
  })
);

businessRouter.get(
  "/mine",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const businesses = all(
      "SELECT id, idea, business_plan, startup_cost, break_even_months, created_at FROM businesses WHERE user_id = ? ORDER BY created_at DESC",
      [req.user!.userId]
    );
    res.json(
      businesses.map((b: any) => ({ ...b, business_plan: JSON.parse(b.business_plan) }))
    );
  })
);
