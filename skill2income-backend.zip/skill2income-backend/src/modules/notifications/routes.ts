import { Router } from "express";
import { all, run } from "../../db";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";

export const notificationsRouter = Router();

notificationsRouter.get(
  "/",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const notifications = all(
      "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30",
      [req.user!.userId]
    );
    res.json(notifications);
  })
);

notificationsRouter.post(
  "/:notificationId/read",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    run("UPDATE notifications SET read_at = datetime('now') WHERE id = ? AND user_id = ?", [
      req.params.notificationId,
      req.user!.userId,
    ]);
    res.json({ ok: true });
  })
);
