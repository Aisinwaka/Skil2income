import { Router } from "express";
import { z } from "zod";
import { get, run } from "../../db";
import { id } from "../../lib/id";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";
import { computeReadinessScore } from "../../lib/scoring";
import { generateBlueprintNarrative } from "../../lib/ai";

export const assessmentRouter = Router();

const answersSchema = z.object({
  age: z.number().optional(),
  educationLevel: z.string().optional(),
  incomeRange: z.string().optional(),
  skills: z.array(z.string()).optional(),
  experienceYears: z.number().optional(),
  internetAccess: z.enum(["none", "limited", "stable"]).optional(),
  hasDevice: z.boolean().optional(),
  portfolioItems: z.number().optional(),
  networkSize: z.enum(["small", "medium", "large"]).optional(),
  location: z.string().optional(),
  careerGoals: z.string().optional(),
  preferredWorkStyle: z.string().optional(),
});

assessmentRouter.post(
  "/",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const answers = answersSchema.parse(req.body);
    const userId = req.user!.userId;

    const { total, breakdown, recommendations } = computeReadinessScore(answers);

    const assessmentId = id();
    run(
      "INSERT INTO assessments (id, user_id, answers, readiness_score, score_breakdown) VALUES (?, ?, ?, ?, ?)",
      [assessmentId, userId, JSON.stringify(answers), total, JSON.stringify(breakdown)]
    );

    const narrative = await generateBlueprintNarrative(JSON.stringify(answers), total);

    const blueprintId = id();
    run(
      `INSERT INTO income_blueprints
        (id, user_id, assessment_id, recommended_path, monthly_goals, expected_income_range, milestones, risk_analysis, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
      [
        blueprintId,
        userId,
        assessmentId,
        narrative.recommendedPath,
        JSON.stringify(narrative.monthlyGoals),
        total >= 60 ? "₦80,000 – ₦150,000/mo" : "₦30,000 – ₦80,000/mo",
        JSON.stringify(narrative.monthlyGoals.map((g, i) => ({ order: i + 1, label: g, done: false }))),
        narrative.riskAnalysis,
      ]
    );

    res.status(201).json({
      assessmentId,
      blueprintId,
      readinessScore: total,
      scoreBreakdown: breakdown,
      recommendations,
      recommendedPath: narrative.recommendedPath,
      monthlyGoals: narrative.monthlyGoals,
    });
  })
);

assessmentRouter.get(
  "/latest",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const assessment = get(
      "SELECT * FROM assessments WHERE user_id = ? ORDER BY created_at DESC LIMIT 1",
      [req.user!.userId]
    );
    if (!assessment) return res.json(null);

    const blueprint = get(
      "SELECT * FROM income_blueprints WHERE assessment_id = ? ORDER BY created_at DESC LIMIT 1",
      [(assessment as any).id]
    );

    res.json({ assessment, blueprint });
  })
);
