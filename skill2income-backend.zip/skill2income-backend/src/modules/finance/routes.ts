import { Router } from "express";
import { z } from "zod";
import { all, run } from "../../db";
import { id } from "../../lib/id";
import { asyncHandler } from "../../lib/async-handler";
import { requireAuth, AuthedRequest } from "../../middleware/auth";

export const financeRouter = Router();

const txSchema = z.object({
  type: z.enum(["income", "expense", "savings"]),
  category: z.string().optional(),
  amount: z.number().positive(),
  occurredAt: z.string().datetime().optional(),
});

financeRouter.get(
  "/transactions",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const transactions = all(
      "SELECT * FROM transactions WHERE user_id = ? ORDER BY occurred_at DESC LIMIT 50",
      [req.user!.userId]
    );
    res.json(transactions);
  })
);

financeRouter.post(
  "/transactions",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const body = txSchema.parse(req.body);
    const txId = id();
    run(
      "INSERT INTO transactions (id, user_id, type, category, amount, occurred_at) VALUES (?, ?, ?, ?, ?, ?)",
      [txId, req.user!.userId, body.type, body.category ?? null, body.amount, body.occurredAt ?? new Date().toISOString()]
    );
    res.status(201).json({ id: txId, ...body });
  })
);

financeRouter.get(
  "/summary",
  requireAuth,
  asyncHandler(async (req: AuthedRequest, res) => {
    const userId = req.user!.userId;

    const byCategory = all<{ category: string | null; total: number }>(
      `SELECT category, SUM(amount) as total FROM transactions
       WHERE user_id = ? AND type = 'expense' GROUP BY category`,
      [userId]
    );

    const incomeTotal = all<{ total: number }>(
      "SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE user_id = ? AND type = 'income'",
      [userId]
    )[0]?.total ?? 0;

    const expenseTotal = all<{ total: number }>(
      "SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE user_id = ? AND type = 'expense'",
      [userId]
    )[0]?.total ?? 0;

    const savingsTotal = all<{ total: number }>(
      "SELECT COALESCE(SUM(amount),0) as total FROM transactions WHERE user_id = ? AND type = 'savings'",
      [userId]
    )[0]?.total ?? 0;

    // Simple linear forecast: average of last 3 income entries, +growth nudge.
    const recentIncomes = all<{ amount: number }>(
      "SELECT amount FROM transactions WHERE user_id = ? AND type = 'income' ORDER BY occurred_at DESC LIMIT 3",
      [userId]
    );
    const avgIncome =
      recentIncomes.length > 0
        ? recentIncomes.reduce((a, b) => a + b.amount, 0) / recentIncomes.length
        : 0;
    const forecastNextMonth = Math.round(avgIncome * 1.12);

    res.json({
      byCategory,
      incomeTotal,
      expenseTotal,
      savingsTotal,
      forecastNextMonth,
      forecastGrowthPct: 12,
    });
  })
);
