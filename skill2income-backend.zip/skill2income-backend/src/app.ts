import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import "./db"; // ensures schema is applied on boot

import { authRouter } from "./modules/auth/routes";
import { assessmentRouter } from "./modules/assessment/routes";
import { dashboardRouter } from "./modules/dashboard/routes";
import { jobsRouter } from "./modules/jobs/routes";
import { chatRouter } from "./modules/chat/routes";
import { businessRouter } from "./modules/business/routes";
import { financeRouter } from "./modules/finance/routes";
import { opportunitiesRouter } from "./modules/opportunities/routes";
import { notificationsRouter } from "./modules/notifications/routes";
import { errorHandler, notFoundHandler } from "./middleware/error";

export function createApp() {
  const app = express();

  app.use(helmet());
  app.use(
    cors({
      origin: process.env.CORS_ORIGIN?.split(",") ?? "*",
      credentials: true,
    })
  );
  app.use(express.json());
  if (process.env.NODE_ENV !== "test") {
    app.use(morgan("dev"));
  }

  // Global rate limit — tighter limits can be applied per-router if needed.
  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 300,
      standardHeaders: true,
      legacyHeaders: false,
    })
  );

  app.get("/health", (_req, res) => res.json({ status: "ok", service: "skill2income-backend" }));

  app.use("/auth", authRouter);
  app.use("/assessment", assessmentRouter);
  app.use("/dashboard", dashboardRouter);
  app.use("/jobs", jobsRouter);
  app.use("/chat", chatRouter);
  app.use("/business", businessRouter);
  app.use("/finance", financeRouter);
  app.use("/opportunities", opportunitiesRouter);
  app.use("/notifications", notificationsRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
