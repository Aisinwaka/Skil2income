import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";

describe("Finance", () => {
  it("rejects transaction logging without auth", async () => {
    const res = await request(app).post("/finance/transactions").send({ type: "income", amount: 1000 });
    expect(res.status).toBe(401);
  });

  it("rejects an invalid transaction type", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/finance/transactions")
      .set("Authorization", `Bearer ${token}`)
      .send({ type: "bogus", amount: 1000 });
    expect(res.status).toBe(400);
  });

  it("rejects a negative amount", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/finance/transactions")
      .set("Authorization", `Bearer ${token}`)
      .send({ type: "expense", amount: -500 });
    expect(res.status).toBe(400);
  });

  it("logs transactions and computes an accurate summary", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    await request(app).post("/finance/transactions").set(auth).send({ type: "income", category: "sales", amount: 35000 });
    await request(app).post("/finance/transactions").set(auth).send({ type: "expense", category: "materials", amount: 12000 });
    await request(app).post("/finance/transactions").set(auth).send({ type: "savings", category: "emergency fund", amount: 5000 });

    const summary = await request(app).get("/finance/summary").set(auth);
    expect(summary.status).toBe(200);
    expect(summary.body.incomeTotal).toBe(35000);
    expect(summary.body.expenseTotal).toBe(12000);
    expect(summary.body.savingsTotal).toBe(5000);
    expect(summary.body.forecastNextMonth).toBeGreaterThan(0);
  });

  it("scopes transactions per-user — one user cannot see another's data", async () => {
    const tokenA = await getAuthToken(uniquePhone());
    const tokenB = await getAuthToken(uniquePhone());

    await request(app)
      .post("/finance/transactions")
      .set("Authorization", `Bearer ${tokenA}`)
      .send({ type: "income", amount: 99999 });

    const summaryB = await request(app)
      .get("/finance/summary")
      .set("Authorization", `Bearer ${tokenB}`);

    expect(summaryB.body.incomeTotal).toBe(0);
  });
});
