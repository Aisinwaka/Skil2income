import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";
import { run } from "../src/db";
import { id } from "../src/lib/id";

let jobId: string;

beforeAll(() => {
  jobId = id();
  run(
    `INSERT INTO jobs (id, title, employer, location, salary_min, salary_max, skills_required, description, source)
     VALUES (?, 'Social Media Assistant', 'Konga', 'Remote', 80000, 120000, 'social media,canva', 'desc', 'test')`,
    [jobId]
  );
});

describe("Jobs", () => {
  it("lists seeded jobs publicly, no auth required", async () => {
    const res = await request(app).get("/jobs");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.some((j: any) => j.id === jobId)).toBe(true);
  });

  it("filters jobs by location", async () => {
    const res = await request(app).get("/jobs").query({ location: "Remote" });
    expect(res.status).toBe(200);
    expect(res.body.every((j: any) => j.location.includes("Remote"))).toBe(true);
  });

  it("filters jobs by search term against title/employer", async () => {
    const res = await request(app).get("/jobs").query({ search: "Konga" });
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("rejects applying without auth", async () => {
    const res = await request(app).post(`/jobs/${jobId}/apply`).send({ status: "applied" });
    expect(res.status).toBe(401);
  });

  it("returns 404 applying to a nonexistent job", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post(`/jobs/does-not-exist/apply`)
      .set("Authorization", `Bearer ${token}`)
      .send({ status: "applied" });
    expect(res.status).toBe(404);
  });

  it("saves then applies to a job, and reflects status in the tracker", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    const saveRes = await request(app).post(`/jobs/${jobId}/apply`).set(auth).send({ status: "saved" });
    expect(saveRes.status).toBe(200);
    expect(saveRes.body.status).toBe("saved");

    const applyRes = await request(app).post(`/jobs/${jobId}/apply`).set(auth).send({ status: "applied" });
    expect(applyRes.status).toBe(200);
    expect(applyRes.body.status).toBe("applied");
    expect(applyRes.body.matchPercentage).toBeGreaterThanOrEqual(50);
    expect(applyRes.body.matchPercentage).toBeLessThanOrEqual(95);

    const trackerRes = await request(app).get("/jobs/applications/mine").set(auth);
    expect(trackerRes.status).toBe(200);
    expect(trackerRes.body).toHaveLength(1);
    expect(trackerRes.body[0].status).toBe("applied");
  });
});
