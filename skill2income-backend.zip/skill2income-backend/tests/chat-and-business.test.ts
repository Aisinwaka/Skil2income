import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";

describe("Chat", () => {
  it("rejects sending a message without auth", async () => {
    const res = await request(app).post("/chat/message").send({ message: "hi" });
    expect(res.status).toBe(401);
  });

  it("returns a fallback reply when no ANTHROPIC_API_KEY is configured", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/chat/message")
      .set("Authorization", `Bearer ${token}`)
      .send({ message: "I applied to 3 jobs, no replies yet", language: "en" });

    expect(res.status).toBe(200);
    expect(typeof res.body.reply).toBe("string");
    expect(res.body.reply.length).toBeGreaterThan(0);
  });

  it("persists chat history across messages", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    await request(app).post("/chat/message").set(auth).send({ message: "first message" });
    await request(app).post("/chat/message").set(auth).send({ message: "second message" });

    const historyRes = await request(app).get("/chat").set(auth);
    expect(historyRes.status).toBe(200);
    // 2 user messages + 2 assistant replies
    expect(historyRes.body.messages.length).toBe(4);
  });

  it("rejects an empty message", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/chat/message")
      .set("Authorization", `Bearer ${token}`)
      .send({ message: "" });
    expect(res.status).toBe(400);
  });
});

describe("BusinessAI", () => {
  it("rejects generating a plan without auth", async () => {
    const res = await request(app).post("/business/generate").send({ idea: "x", budgetNaira: 1000 });
    expect(res.status).toBe(401);
  });

  it("generates a rule-based plan when no ANTHROPIC_API_KEY is configured", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/business/generate")
      .set("Authorization", `Bearer ${token}`)
      .send({ idea: "Custom Ankara outfits sold via Instagram", budgetNaira: 80000 });

    expect(res.status).toBe(201);
    expect(res.body.plan.startupCostBreakdown.length).toBeGreaterThan(0);
    expect(res.body.plan.swot).toBeDefined();
    expect(res.body.plan.businessModelCanvas).toBeDefined();
  });

  it("rejects a non-positive budget", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/business/generate")
      .set("Authorization", `Bearer ${token}`)
      .send({ idea: "Something", budgetNaira: -100 });
    expect(res.status).toBe(400);
  });

  it("lists previously generated plans for the user", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };
    await request(app).post("/business/generate").set(auth).send({ idea: "Idea A", budgetNaira: 50000 });

    const res = await request(app).get("/business/mine").set(auth);
    expect(res.status).toBe(200);
    expect(res.body.length).toBe(1);
    expect(res.body[0].idea).toBe("Idea A");
  });
});
