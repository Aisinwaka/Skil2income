import { describe, it, expect } from "vitest";
import { computeReadinessScore } from "../src/lib/scoring";

describe("computeReadinessScore", () => {
  it("returns a score between 0 and 100 for an empty answer set", () => {
    const { total, breakdown } = computeReadinessScore({});
    expect(total).toBeGreaterThanOrEqual(0);
    expect(total).toBeLessThanOrEqual(100);
    expect(Object.keys(breakdown)).toHaveLength(8);
  });

  it("scores a strong profile higher than a weak one", () => {
    const weak = computeReadinessScore({
      educationLevel: "none",
      skills: [],
      experienceYears: 0,
      internetAccess: "none",
      hasDevice: false,
      portfolioItems: 0,
      networkSize: "small",
      incomeRange: "none",
    });

    const strong = computeReadinessScore({
      educationLevel: "msc_plus",
      skills: ["social media", "canva", "copywriting"],
      experienceYears: 5,
      internetAccess: "stable",
      hasDevice: true,
      portfolioItems: 4,
      networkSize: "large",
      incomeRange: "150k+",
    });

    expect(strong.total).toBeGreaterThan(weak.total);
  });

  it("never returns a category score outside 0-100", () => {
    const { breakdown } = computeReadinessScore({
      skills: ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"], // way more than the cap
      portfolioItems: 99,
      experienceYears: 999,
    });
    Object.values(breakdown).forEach((v) => {
      expect(v).toBeGreaterThanOrEqual(0);
      expect(v).toBeLessThanOrEqual(100);
    });
  });

  it("produces improvement recommendations for weak categories", () => {
    const { recommendations } = computeReadinessScore({
      skills: [],
      portfolioItems: 0,
      networkSize: "small",
      experienceYears: 0,
      internetAccess: "none",
    });
    expect(recommendations.length).toBeGreaterThan(0);
  });

  it("produces fewer recommendations for a strong profile", () => {
    const weak = computeReadinessScore({ skills: [], portfolioItems: 0, networkSize: "small" });
    const strong = computeReadinessScore({
      skills: ["a", "b", "c"],
      portfolioItems: 3,
      networkSize: "large",
      experienceYears: 5,
      internetAccess: "stable",
    });
    expect(strong.recommendations.length).toBeLessThanOrEqual(weak.recommendations.length);
  });
});
