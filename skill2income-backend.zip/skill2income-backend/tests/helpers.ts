import request from "supertest";
import { createApp } from "../src/app";

export const app = createApp();

/** Registers + verifies a fresh phone number and returns a bearer token. */
export async function getAuthToken(phone: string): Promise<string> {
  const otpRes = await request(app).post("/auth/otp/request").send({ phone });
  const code = otpRes.body.devCode;

  const verifyRes = await request(app).post("/auth/otp/verify").send({ phone, code });
  return verifyRes.body.token as string;
}

let counter = 0;
/** Generates a unique Nigerian-looking phone number per test to avoid collisions. */
export function uniquePhone(): string {
  counter += 1;
  return `+23480${String(10000000 + counter).padStart(8, "0")}`;
}
