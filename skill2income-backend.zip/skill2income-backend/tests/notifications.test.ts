import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";
import { run } from "../src/db";
import { id } from "../src/lib/id";

describe("Notifications", () => {
  it("rejects listing without auth", async () => {
    const res = await request(app).get("/notifications");
    expect(res.status).toBe(401);
  });

  it("returns an empty list for a new user", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app).get("/notifications").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body).toEqual([]);
  });

  it("lists and marks a notification as read", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    // Get the user id via /auth/me to insert a notification directly (no admin-create route exists yet)
    const me = await request(app).get("/auth/me").set(auth);
    const notifId = id();
    run("INSERT INTO notifications (id, user_id, channel, message) VALUES (?, ?, 'push', 'Welcome to Skill2Income!')", [
      notifId,
      me.body.id,
    ]);

    const listRes = await request(app).get("/notifications").set(auth);
    expect(listRes.status).toBe(200);
    expect(listRes.body.length).toBe(1);
    expect(listRes.body[0].read_at).toBeNull();

    const readRes = await request(app).post(`/notifications/${notifId}/read`).set(auth);
    expect(readRes.status).toBe(200);

    const listAfter = await request(app).get("/notifications").set(auth);
    expect(listAfter.body[0].read_at).not.toBeNull();
  });

  it("does not let a user mark another user's notification as read", async () => {
    const tokenA = await getAuthToken(uniquePhone());
    const tokenB = await getAuthToken(uniquePhone());
    const meA = await request(app).get("/auth/me").set("Authorization", `Bearer ${tokenA}`);

    const notifId = id();
    run("INSERT INTO notifications (id, user_id, channel, message) VALUES (?, ?, 'push', 'Private to A')", [
      notifId,
      meA.body.id,
    ]);

    await request(app).post(`/notifications/${notifId}/read`).set("Authorization", `Bearer ${tokenB}`);

    const listA = await request(app).get("/notifications").set("Authorization", `Bearer ${tokenA}`);
    // Still unread — user B's request should not have affected it
    expect(listA.body[0].read_at).toBeNull();
  });
});
