import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { app } from "./helpers";
import { run } from "../src/db";
import { id } from "../src/lib/id";

describe("App-wide", () => {
  it("responds to the health check", async () => {
    const res = await request(app).get("/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
  });

  it("returns a JSON 404 for unknown routes", async () => {
    const res = await request(app).get("/this-route-does-not-exist");
    expect(res.status).toBe(404);
    expect(res.body.error).toBeDefined();
  });
});

describe("Opportunities", () => {
  beforeAll(() => {
    run(
      "INSERT INTO opportunities (id, type, title, deadline, link, eligibility) VALUES (?, 'grant', 'Test Grant', '2027-01-01', 'https://example.com', 'Everyone')",
      [id()]
    );
  });

  it("lists opportunities publicly", async () => {
    const res = await request(app).get("/opportunities");
    expect(res.status).toBe(200);
    expect(res.body.length).toBeGreaterThan(0);
  });

  it("filters opportunities by type", async () => {
    const res = await request(app).get("/opportunities").query({ type: "grant" });
    expect(res.status).toBe(200);
    expect(res.body.every((o: any) => o.type === "grant")).toBe(true);
  });
});
