import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";

describe("Assessment", () => {
  it("rejects submission without auth", async () => {
    const res = await request(app).post("/assessment").send({});
    expect(res.status).toBe(401);
  });

  it("computes a readiness score and generates a blueprint", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/assessment")
      .set("Authorization", `Bearer ${token}`)
      .send({
        age: 24,
        educationLevel: "bsc_hnd",
        incomeRange: "10-50k",
        skills: ["social media", "canva"],
        experienceYears: 1,
        internetAccess: "limited",
        hasDevice: true,
        portfolioItems: 1,
        networkSize: "small",
        careerGoals: "Land a digital marketing role",
        preferredWorkStyle: "employment",
      });

    expect(res.status).toBe(201);
    expect(res.body.readinessScore).toBeGreaterThanOrEqual(0);
    expect(res.body.readinessScore).toBeLessThanOrEqual(100);
    expect(res.body.scoreBreakdown).toBeDefined();
    expect(Array.isArray(res.body.monthlyGoals)).toBe(true);
    expect(res.body.monthlyGoals.length).toBeGreaterThan(0);
    expect(typeof res.body.recommendedPath).toBe("string");
  });

  it("rejects an invalid internetAccess enum value", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .post("/assessment")
      .set("Authorization", `Bearer ${token}`)
      .send({ internetAccess: "fiber-optic" });
    expect(res.status).toBe(400);
  });

  it("returns null when no assessment exists yet", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app)
      .get("/assessment/latest")
      .set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body).toBeNull();
  });

  it("returns the latest assessment + blueprint after submission", async () => {
    const token = await getAuthToken(uniquePhone());
    await request(app)
      .post("/assessment")
      .set("Authorization", `Bearer ${token}`)
      .send({ skills: ["excel"] });

    const res = await request(app)
      .get("/assessment/latest")
      .set("Authorization", `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.assessment).toBeDefined();
    expect(res.body.blueprint).toBeDefined();
  });
});
