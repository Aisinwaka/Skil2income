// Runs before any test file's modules are imported, so src/db/index.ts picks
// up an isolated in-memory database instead of touching dev.db.
process.env.NODE_ENV = "test";
process.env.DATABASE_FILE = ":memory:";
process.env.JWT_SECRET = "test-secret-do-not-use-in-production";
process.env.CORS_ORIGIN = "http://localhost:3000";
// Deliberately unset so AI-backed endpoints exercise their fallback paths.
delete process.env.ANTHROPIC_API_KEY;
