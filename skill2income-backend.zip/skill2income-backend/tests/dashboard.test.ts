import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";

describe("Dashboard", () => {
  it("rejects without auth", async () => {
    const res = await request(app).get("/dashboard");
    expect(res.status).toBe(401);
  });

  it("returns a sensible empty-state shape for a brand-new user", async () => {
    const token = await getAuthToken(uniquePhone());
    const res = await request(app).get("/dashboard").set("Authorization", `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.readinessScore).toBeNull();
    expect(res.body.roadmap).toBeNull();
    expect(Array.isArray(res.body.recentTransactions)).toBe(true);
  });

  it("reflects the score and roadmap after completing an assessment", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    await request(app).post("/assessment").set(auth).send({ skills: ["excel", "canva"] });

    const res = await request(app).get("/dashboard").set(auth);
    expect(res.status).toBe(200);
    expect(res.body.readinessScore).toBeGreaterThanOrEqual(0);
    expect(res.body.roadmap).not.toBeNull();
    expect(res.body.roadmap.recommendedPath).toBeDefined();
  });

  it("includes recent transactions once logged", async () => {
    const token = await getAuthToken(uniquePhone());
    const auth = { Authorization: `Bearer ${token}` };

    await request(app).post("/finance/transactions").set(auth).send({ type: "income", amount: 20000 });

    const res = await request(app).get("/dashboard").set(auth);
    expect(res.body.recentTransactions.length).toBe(1);
  });
});
