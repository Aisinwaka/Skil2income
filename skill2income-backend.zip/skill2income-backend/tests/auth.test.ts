import { describe, it, expect } from "vitest";
import request from "supertest";
import { app, uniquePhone, getAuthToken } from "./helpers";

describe("Auth — phone/OTP", () => {
  it("issues an OTP and returns a devCode in this dev build", async () => {
    const phone = uniquePhone();
    const res = await request(app).post("/auth/otp/request").send({ phone });
    expect(res.status).toBe(200);
    expect(res.body.devCode).toMatch(/^\d{6}$/);
  });

  it("rejects verification with a wrong code", async () => {
    const phone = uniquePhone();
    await request(app).post("/auth/otp/request").send({ phone });
    const res = await request(app).post("/auth/otp/verify").send({ phone, code: "000000" });
    expect(res.status).toBe(401);
  });

  it("verifies a correct OTP and returns a JWT, creating a new user", async () => {
    const phone = uniquePhone();
    const otpRes = await request(app).post("/auth/otp/request").send({ phone });
    const verifyRes = await request(app)
      .post("/auth/otp/verify")
      .send({ phone, code: otpRes.body.devCode });

    expect(verifyRes.status).toBe(200);
    expect(typeof verifyRes.body.token).toBe("string");
  });

  it("rejects reusing an already-consumed OTP code", async () => {
    const phone = uniquePhone();
    const otpRes = await request(app).post("/auth/otp/request").send({ phone });
    const code = otpRes.body.devCode;

    const first = await request(app).post("/auth/otp/verify").send({ phone, code });
    expect(first.status).toBe(200);

    const second = await request(app).post("/auth/otp/verify").send({ phone, code });
    expect(second.status).toBe(401);
  });

  it("logs the same user back in on a second OTP cycle instead of duplicating", async () => {
    const phone = uniquePhone();
    const token1 = await getAuthToken(phone);

    const otpRes2 = await request(app).post("/auth/otp/request").send({ phone });
    const verify2 = await request(app)
      .post("/auth/otp/verify")
      .send({ phone, code: otpRes2.body.devCode });

    const me1 = await request(app).get("/auth/me").set("Authorization", `Bearer ${token1}`);
    const me2 = await request(app)
      .get("/auth/me")
      .set("Authorization", `Bearer ${verify2.body.token}`);

    expect(me1.body.id).toBe(me2.body.id);
  });
});

describe("Auth — email/password", () => {
  it("registers a new account and returns a token", async () => {
    const email = `user${Date.now()}@example.com`;
    const res = await request(app).post("/auth/register").send({ email, password: "supersecret" });
    expect(res.status).toBe(201);
    expect(typeof res.body.token).toBe("string");
  });

  it("rejects registering the same email twice", async () => {
    const email = `dup${Date.now()}@example.com`;
    await request(app).post("/auth/register").send({ email, password: "supersecret" });
    const res = await request(app).post("/auth/register").send({ email, password: "supersecret" });
    expect(res.status).toBe(409);
  });

  it("logs in with correct credentials", async () => {
    const email = `login${Date.now()}@example.com`;
    await request(app).post("/auth/register").send({ email, password: "supersecret" });
    const res = await request(app).post("/auth/login").send({ email, password: "supersecret" });
    expect(res.status).toBe(200);
    expect(typeof res.body.token).toBe("string");
  });

  it("rejects login with wrong password", async () => {
    const email = `wrongpw${Date.now()}@example.com`;
    await request(app).post("/auth/register").send({ email, password: "supersecret" });
    const res = await request(app).post("/auth/login").send({ email, password: "wrongpassword" });
    expect(res.status).toBe(401);
  });

  it("rejects a password under 6 characters at the validation layer", async () => {
    const res = await request(app)
      .post("/auth/register")
      .send({ email: `short${Date.now()}@example.com`, password: "123" });
    expect(res.status).toBe(400);
  });
});

describe("Auth — protected routes", () => {
  it("rejects /auth/me with no token", async () => {
    const res = await request(app).get("/auth/me");
    expect(res.status).toBe(401);
  });

  it("rejects /auth/me with a garbage token", async () => {
    const res = await request(app).get("/auth/me").set("Authorization", "Bearer garbage.token.here");
    expect(res.status).toBe(401);
  });

  it("returns the user profile with a valid token", async () => {
    const phone = uniquePhone();
    const token = await getAuthToken(phone);
    const res = await request(app).get("/auth/me").set("Authorization", `Bearer ${token}`);
    expect(res.status).toBe(200);
    expect(res.body.phone).toBe(phone);
  });
});
