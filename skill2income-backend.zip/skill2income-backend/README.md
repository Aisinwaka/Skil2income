# Skill2Income — Backend

Phase 4 deliverable: a real, working API server implementing every endpoint the
Phase 3 frontend needs — auth, AI assessment & scoring, dashboard, jobs, AI
chat, BusinessAI, FinanceAI, opportunities, and notifications.

## Honest scope note

The master spec calls for a full microservices architecture (separate Auth,
AI, Jobs, Learning, Business, Finance, Notification, Analytics, and Admin
services behind an API gateway, with Kafka, a vector DB, PostgreSQL, Redis,
and MongoDB). Standing all of that up requires real cloud infrastructure —
it's not something that can be "delivered" as a file.

What you have here instead is a **modular monolith**: one Express server,
organized into the same module boundaries the microservices would eventually
have (`src/modules/auth`, `src/modules/jobs`, `src/modules/business`, etc.),
each with its own routes file. This is a deliberate, standard way to build a
real product — you get one deployable thing today, and each module is already
shaped so it can be lifted out into its own service later without a rewrite.

## Stack

- **Node.js + TypeScript + Express 5**
- **SQLite** via Node's built-in `node:sqlite` (zero native dependencies —
  works out of the box, no compilers or Docker needed). Swap to Postgres for
  production by changing `src/db/index.ts` to a `pg` connection (schema in
  `src/db/schema.sql` is already Postgres-compatible SQL).
- **JWT** auth (phone/OTP primary flow, email/password secondary, Google stub)
- **Anthropic API** (Claude) powers the AI Mentor chat, BusinessAI plan
  generation, and Income Blueprint narrative — with automatic rule-based
  fallbacks so every endpoint works even with no API key configured.
- **zod** for request validation, **helmet** + **express-rate-limit** for
  baseline security, **bcryptjs** for password hashing.

## Deploying

`Dockerfile`, `railway.json`, and `render.yaml` are included and ready to
use — see the top-level `DEPLOYMENT.md` (shipped alongside this project)
for exact commands. Short version: this needs a **persistent disk** for the
SQLite file (both configs already set one up), so use Railway or Render,
not a serverless/edge platform.

## Testing

```bash
npm test              # run once
npm run test:watch     # watch mode
npm run test:coverage   # with coverage report
```

54 tests across 9 files (Vitest + Supertest), covering every module: auth
(OTP flow, email/password, token validation), assessment scoring +
blueprint generation, dashboard aggregation, jobs + application tracking,
AI chat (fallback path), BusinessAI (fallback path), finance summaries
(including per-user data isolation), opportunities, and notifications —
plus a pure unit test suite for the Income Readiness Score engine.

Tests run against an isolated **in-memory SQLite database** (`:memory:`,
configured in `tests/setup.ts`) so they never touch `dev.db` and are safe to
run repeatedly. AI-backed endpoints are tested against their rule-based
fallback path, since no `ANTHROPIC_API_KEY` is set in the test environment —
current coverage is ~91% statements, with the main gaps being the
real-API-key code path in `lib/ai.ts` (untestable without live credentials)
and a minor branch in the role-guard middleware (`requireRole`, not yet used
by any route).

## Getting started

```bash
npm install
cp .env.example .env   # then optionally add your ANTHROPIC_API_KEY
npm run seed            # creates dev.db with demo jobs + opportunities
npm run dev              # http://localhost:4000
```

To enable real AI responses (chat, BusinessAI, blueprint generation), set
`ANTHROPIC_API_KEY` in `.env`. Without it, every AI-backed endpoint still
returns a sensible rule-based response — nothing breaks, nothing is a stub
that 404s.

## API reference

| Method | Route                        | Auth | Description |
|--------|-------------------------------|------|--------------|
| POST   | `/auth/otp/request`           | –    | Request OTP for phone login (dev: code returned in response) |
| POST   | `/auth/otp/verify`             | –    | Verify OTP, creates user if new, returns JWT |
| POST   | `/auth/register`               | –    | Email/password registration |
| POST   | `/auth/login`                   | –    | Email/password login |
| GET    | `/auth/me`                       | ✓    | Current user + profile |
| POST   | `/assessment`                    | ✓    | Submit answers → Income Readiness Score + Blueprint |
| GET    | `/assessment/latest`             | ✓    | Latest assessment + blueprint |
| GET    | `/dashboard`                      | ✓    | Aggregated score, roadmap, recommended job, recent transactions |
| GET    | `/jobs`                            | –    | List/search jobs (`?search=`, `?location=`) |
| POST   | `/jobs/:jobId/apply`               | ✓    | Save or apply to a job |
| GET    | `/jobs/applications/mine`           | ✓    | My application tracker |
| GET    | `/chat`                              | ✓    | Chat history |
| POST   | `/chat/message`                      | ✓    | Send a message, get AI Mentor reply |
| POST   | `/business/generate`                  | ✓    | Generate a BusinessAI plan from idea + budget |
| GET    | `/business/mine`                       | ✓    | My generated business plans |
| GET    | `/finance/transactions`                | ✓    | Recent transactions |
| POST   | `/finance/transactions`                 | ✓    | Log a transaction |
| GET    | `/finance/summary`                       | ✓    | Budget breakdown, totals, forecast |
| GET    | `/opportunities`                          | –    | List opportunities (`?type=grant\|scholarship\|nysc\|...`) |
| GET    | `/notifications`                           | ✓    | My notifications |
| POST   | `/notifications/:id/read`                  | ✓    | Mark notification read |
| GET    | `/health`                                    | –    | Health check |

Protected routes require `Authorization: Bearer <token>` from the OTP or
email login response.

## Project structure

```
src/
  app.ts                Express app assembly (middleware + routers)
  server.ts             Entry point
  db/
    schema.sql            SQLite schema (Postgres-compatible)
    index.ts               Connection + query helpers
    seed.ts                 Demo data matching the frontend mocks
  lib/
    scoring.ts              Income Readiness Score engine (8-category, rule-based)
    ai.ts                     Anthropic API wrapper + fallbacks
    jwt.ts, id.ts, async-handler.ts
  middleware/
    auth.ts                 JWT verification, role guard
    error.ts                 Centralized error handling
  modules/
    auth/ assessment/ dashboard/ jobs/ chat/ business/ finance/
    opportunities/ notifications/     each: routes.ts
```

## Scoring engine

`src/lib/scoring.ts` computes the Income Readiness Score across the 8
categories from the PRD (digital skills, communication, education, portfolio,
experience, market demand, location, networking) using explainable,
adjustable rules — not a black box. Swap in a trained model later without
changing the API contract; `POST /assessment` always returns
`{ readinessScore, scoreBreakdown, recommendations }`.

## Security notes for production

- Rotate `JWT_SECRET` and keep it out of source control.
- The OTP endpoint currently logs the code to the console and returns it in
  the response body (`devCode`) for local testing — wire up a real SMS
  provider (Termii, Africa's Talking, Twilio) and remove `devCode` before
  shipping.
- Add per-route rate limits on `/auth/otp/request` specifically to prevent
  SMS-bombing abuse.
- Move from SQLite to Postgres for any multi-instance deployment (SQLite is
  single-file/single-writer).

## Next steps (Phase 5+)

- Point the Phase 3 frontend at this API (replace the mock arrays in each
  page with `fetch`/React Query calls to these routes).
- Add refresh tokens / session revocation.
- Split into real microservices once you have infra (Docker Compose first,
  Kubernetes when you actually need to scale past one box).
- Add the Learning module (courses/certificates) and Notifications delivery
  (push/SMS/WhatsApp) — schema tables already exist, routes are the only
  missing piece.
