import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { ChatBubble } from "@/components/shared/chat-bubble";

describe("ChatBubble", () => {
  it("renders AI message content with left-aligned styling", () => {
    render(<ChatBubble from="ai">Sannu Amina!</ChatBubble>);
    const bubble = screen.getByText("Sannu Amina!");
    expect(bubble).toHaveClass("self-start");
    expect(bubble).toHaveClass("bg-bg");
  });

  it("renders user message content with right-aligned styling", () => {
    render(<ChatBubble from="user">Yes please</ChatBubble>);
    const bubble = screen.getByText("Yes please");
    expect(bubble).toHaveClass("self-end");
    expect(bubble).toHaveClass("bg-emerald");
  });
});
