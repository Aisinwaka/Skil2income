import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

describe("Badge", () => {
  it("renders its content", () => {
    render(<Badge>86% match</Badge>);
    expect(screen.getByText("86% match")).toBeInTheDocument();
  });

  it("applies the emerald variant by default", () => {
    render(<Badge>Default</Badge>);
    expect(screen.getByText("Default")).toHaveClass("bg-emerald-tint");
  });

  it("applies the orange variant when specified", () => {
    render(<Badge variant="orange">Urgent</Badge>);
    expect(screen.getByText("Urgent")).toHaveClass("bg-orange-tint");
  });
});

describe("Progress", () => {
  it("sets the fill width to match the value prop", () => {
    const { container } = render(<Progress value={62} />);
    const fill = container.querySelector("div > div > div") as HTMLElement;
    expect(fill.style.width).toBe("62%");
  });

  it("clamps values above 100 to 100%", () => {
    const { container } = render(<Progress value={150} />);
    const fill = container.querySelector("div > div > div") as HTMLElement;
    expect(fill.style.width).toBe("100%");
  });

  it("clamps negative values to 0%", () => {
    const { container } = render(<Progress value={-20} />);
    const fill = container.querySelector("div > div > div") as HTMLElement;
    expect(fill.style.width).toBe("0%");
  });
});
