import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Gauge } from "@/components/shared/gauge";

describe("Gauge", () => {
  it("displays the numeric score", () => {
    render(<Gauge score={68} />);
    expect(screen.getByText("68")).toBeInTheDocument();
  });

  it("displays the label", () => {
    render(<Gauge score={68} label="of 100" />);
    expect(screen.getByText("of 100")).toBeInTheDocument();
  });

  it("renders an SVG arc whose dash offset reflects the score", () => {
    const { container } = render(<Gauge score={100} />);
    const circles = container.querySelectorAll("circle");
    // second circle is the progress arc
    const progressArc = circles[1];
    // at 100/100, the arc should be fully drawn (offset ~0)
    expect(progressArc).toHaveAttribute("stroke-dashoffset", "0");
  });

  it("computes a partial offset for a mid-range score", () => {
    const { container } = render(<Gauge score={0} />);
    const circles = container.querySelectorAll("circle");
    const progressArc = circles[1];
    const circumference = 2 * Math.PI * 50;
    expect(progressArc).toHaveAttribute("stroke-dashoffset", String(circumference));
  });
});
