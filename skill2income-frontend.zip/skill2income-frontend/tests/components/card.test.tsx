import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { Card } from "@/components/ui/card";

describe("Card", () => {
  it("renders its children", () => {
    render(<Card>Roadmap content</Card>);
    expect(screen.getByText("Roadmap content")).toBeInTheDocument();
  });

  it("applies base card styling", () => {
    render(<Card>Styled</Card>);
    expect(screen.getByText("Styled")).toHaveClass("rounded-[20px]", "border", "shadow-card");
  });

  it("merges custom className with the base styles", () => {
    render(<Card className="mt-4">Custom</Card>);
    expect(screen.getByText("Custom")).toHaveClass("mt-4", "rounded-[20px]");
  });
});
