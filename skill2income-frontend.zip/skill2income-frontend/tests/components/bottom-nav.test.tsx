import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { BottomNav } from "@/components/shared/bottom-nav";

vi.mock("next/navigation", () => ({
  usePathname: () => "/jobs",
}));

describe("BottomNav", () => {
  it("renders all five nav items", () => {
    render(<BottomNav />);
    expect(screen.getByText("Home")).toBeInTheDocument();
    expect(screen.getByText("Jobs")).toBeInTheDocument();
    expect(screen.getByText("Chat")).toBeInTheDocument();
    expect(screen.getByText("Income")).toBeInTheDocument();
    expect(screen.getByText("Business")).toBeInTheDocument();
  });

  it("highlights the item matching the current pathname", () => {
    render(<BottomNav />);
    expect(screen.getByText("Jobs").closest("a")).toHaveClass("text-emerald");
  });

  it("does not highlight non-active items", () => {
    render(<BottomNav />);
    expect(screen.getByText("Home").closest("a")).toHaveClass("text-muted-2");
  });
});
