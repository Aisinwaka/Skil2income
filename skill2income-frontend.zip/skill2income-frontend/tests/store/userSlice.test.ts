import { describe, it, expect } from "vitest";
import userReducer, { setAnswer, setReadinessScore } from "@/store/userSlice";

describe("userSlice", () => {
  it("has sensible defaults", () => {
    const state = userReducer(undefined, { type: "@@INIT" });
    expect(state.name).toBeTruthy();
    expect(state.readinessScore).toBeGreaterThanOrEqual(0);
    expect(state.answers).toEqual({});
  });

  it("merges partial answers without overwriting previously set fields", () => {
    let state = userReducer(undefined, setAnswer({ incomeRange: "10-50k" }));
    expect(state.answers.incomeRange).toBe("10-50k");

    state = userReducer(state, setAnswer({ goal: "Get a job" }));
    expect(state.answers.incomeRange).toBe("10-50k");
    expect(state.answers.goal).toBe("Get a job");
  });

  it("overwrites a field when set again", () => {
    let state = userReducer(undefined, setAnswer({ incomeRange: "10-50k" }));
    state = userReducer(state, setAnswer({ incomeRange: "50-150k" }));
    expect(state.answers.incomeRange).toBe("50-150k");
  });

  it("updates the readiness score", () => {
    const state = userReducer(undefined, setReadinessScore(82));
    expect(state.readinessScore).toBe(82);
  });
});
