import { describe, it, expect } from "vitest";
import uiReducer, { toggleTheme, setTheme } from "@/store/uiSlice";

describe("uiSlice", () => {
  it("defaults to light theme", () => {
    const state = uiReducer(undefined, { type: "@@INIT" });
    expect(state.theme).toBe("light");
  });

  it("toggles from light to dark", () => {
    const state = uiReducer({ theme: "light" }, toggleTheme());
    expect(state.theme).toBe("dark");
  });

  it("toggles from dark back to light", () => {
    const state = uiReducer({ theme: "dark" }, toggleTheme());
    expect(state.theme).toBe("light");
  });

  it("sets an explicit theme", () => {
    const state = uiReducer({ theme: "light" }, setTheme("dark"));
    expect(state.theme).toBe("dark");
  });
});
