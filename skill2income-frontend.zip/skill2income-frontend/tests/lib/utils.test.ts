import { describe, it, expect } from "vitest";
import { cn, formatNaira } from "@/lib/utils";

describe("cn", () => {
  it("joins truthy class names", () => {
    expect(cn("a", "b", "c")).toBe("a b c");
  });

  it("drops falsy values", () => {
    expect(cn("a", false, undefined, null, "b")).toBe("a b");
  });

  it("handles conditional object syntax", () => {
    expect(cn("base", { active: true, disabled: false })).toBe("base active");
  });
});

describe("formatNaira", () => {
  it("formats a whole number with the naira sign and thousands separators", () => {
    expect(formatNaira(80000)).toBe("₦80,000");
  });

  it("formats zero correctly", () => {
    expect(formatNaira(0)).toBe("₦0");
  });

  it("formats large numbers with correct grouping", () => {
    expect(formatNaira(2400000000)).toBe("₦2,400,000,000");
  });
});
