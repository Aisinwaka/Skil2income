"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageTransition } from "@/components/shared/page-transition";
import { cn } from "@/lib/utils";

export default function LoginPage() {
  const [mode, setMode] = useState<"phone" | "email">("phone");
  const router = useRouter();

  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col justify-center px-5 py-10">
        <div className="h-[46px] w-[46px] rounded-[14px] bg-gradient-to-br from-emerald to-blue" />
        <h1 className="font-display mt-4 text-2xl font-extrabold">Sannu! Welcome back</h1>
        <p className="mt-1 text-[13.5px] text-muted">
          Log in to continue your income journey.
        </p>

        <div className="mt-5 mb-4 flex gap-1 rounded-xl bg-bg p-1">
          {(["phone", "email"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={cn(
                "flex-1 rounded-lg py-2 text-center text-sm font-bold capitalize",
                mode === m && "bg-surface shadow-card"
              )}
            >
              {m}
            </button>
          ))}
        </div>

        <label className="text-[12px] font-bold text-muted">
          {mode === "phone" ? "PHONE NUMBER" : "EMAIL ADDRESS"}
        </label>
        <div className="mt-1.5 mb-3.5">
          <input
            type={mode === "phone" ? "tel" : "email"}
            placeholder={mode === "phone" ? "+234 803 123 4567" : "you@example.com"}
            className="w-full rounded-xl border-[1.5px] border-border bg-bg px-3.5 py-3.5 text-[14.5px] outline-none focus:border-emerald"
          />
        </div>

        <Button block onClick={() => router.push("/assessment")}>
          {mode === "phone" ? "Send OTP" : "Continue"}
        </Button>

        <div className="my-5 flex items-center gap-2.5 text-xs text-muted">
          <hr className="flex-1 border-border" /> or <hr className="flex-1 border-border" />
        </div>

        <Button variant="secondary" block>
          🔵 Continue with Google
        </Button>

        <div className="mt-5 flex items-start gap-2.5 rounded-[20px] bg-emerald-tint p-4">
          <ShieldCheck size={18} className="mt-0.5 flex-shrink-0 text-emerald-dark" />
          <p className="text-xs leading-relaxed text-emerald-dark">
            We&apos;ll text a 6-digit code to verify it&apos;s you. No password needed
            for phone sign-in.
          </p>
        </div>

        <p className="mt-5 text-center text-[13px] text-muted">
          New here?{" "}
          <Link href="/assessment" className="font-bold text-emerald">
            Create an account
          </Link>
        </p>
      </div>
    </PageTransition>
  );
}
