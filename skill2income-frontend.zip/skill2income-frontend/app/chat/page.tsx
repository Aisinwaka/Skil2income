"use client";

import { useState } from "react";
import { Mic, Send } from "lucide-react";
import { ChatBubble } from "@/components/shared/chat-bubble";
import { BottomNav } from "@/components/shared/bottom-nav";
import { PageTransition } from "@/components/shared/page-transition";
import { cn } from "@/lib/utils";

const languages = ["English", "Hausa", "Yoruba", "Igbo"];

const initialMessages: { from: "ai" | "user"; text: string }[] = [
  {
    from: "ai",
    text: "Sannu Amina! I saw you completed the Canva lesson today — well done. Want to talk through your job applications?",
  },
  {
    from: "user",
    text: "Yes. I applied to 3 jobs this week but no replies yet. Should I be worried?",
  },
  {
    from: "ai",
    text: "Not at all — most Nigerian employers take 1–2 weeks to respond. A polite follow-up after 7 days actually helps. Want me to draft one for the Konga role?",
  },
  { from: "user", text: "Yes please, keep it short and confident." },
  {
    from: "ai",
    text: 'Here\u2019s a short draft: "Hello, I\u2019m following up on my application for the Social Media Assistant role submitted on the 28th. I remain very interested and happy to share more about my portfolio. Thank you." Want me to send this via the Jobs tracker?',
  },
];

const quickPrompts = ["Negotiate my salary", "Business idea, ₦50k budget", "Practice an interview"];

export default function ChatPage() {
  const [lang, setLang] = useState("English");
  const [messages, setMessages] = useState(initialMessages);
  const [draft, setDraft] = useState("");

  function send(text: string) {
    if (!text.trim()) return;
    setMessages((m) => [...m, { from: "user", text }]);
    setDraft("");
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        { from: "ai", text: "Got it — let me put together some thoughts on that for you." },
      ]);
    }, 700);
  }

  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="flex items-center gap-2.5 border-b border-border px-5 py-3.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald to-blue text-base">
            🤖
          </div>
          <div>
            <b className="text-sm">AI Mentor</b>
            <div className="text-[11px] text-emerald">● Online</div>
          </div>
        </div>

        <div className="flex gap-1.5 overflow-x-auto px-5 py-2.5">
          {languages.map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={cn(
                "whitespace-nowrap rounded-full border-[1.5px] border-border px-3 py-1.5 text-xs font-bold",
                lang === l && "border-ink bg-ink text-bg"
              )}
            >
              {l}
            </button>
          ))}
        </div>

        <div className="flex flex-1 flex-col gap-3 overflow-y-auto px-5 pt-1.5">
          {messages.map((m, i) => (
            <div key={i} className="flex flex-col">
              <ChatBubble from={m.from}>{m.text}</ChatBubble>
            </div>
          ))}
        </div>

        <div className="flex gap-1.5 overflow-x-auto px-5 pb-2.5 pt-2">
          {quickPrompts.map((p) => (
            <button
              key={p}
              onClick={() => send(p)}
              className="whitespace-nowrap rounded-xl border border-border bg-bg px-3.5 py-2 text-[12.5px] font-semibold"
            >
              {p}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 border-t border-border px-5 py-2.5">
          <button className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-bg">
            <Mic size={16} />
          </button>
          <input
            type="text"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send(draft)}
            placeholder="Message your AI Mentor…"
            className="flex-1 rounded-full border border-border bg-bg px-4 py-2.5 text-sm outline-none focus:border-emerald"
          />
          <button
            onClick={() => send(draft)}
            className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-emerald text-white"
          >
            <Send size={15} />
          </button>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
