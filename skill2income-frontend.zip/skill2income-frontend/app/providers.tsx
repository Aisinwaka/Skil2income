"use client";

import { useEffect, useState } from "react";
import { Provider, useSelector } from "react-redux";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { store } from "@/store/store";
import type { RootState } from "@/store/store";

const queryClient = new QueryClient();

function ThemeSync({ children }: { children: React.ReactNode }) {
  const theme = useSelector((s: RootState) => s.ui.theme);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
  }, [theme]);

  return <>{children}</>;
}

export function Providers({ children }: { children: React.ReactNode }) {
  // Avoid hydration flash: only render after mount
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <ThemeSync>{mounted ? children : <div style={{ visibility: "hidden" }}>{children}</div>}</ThemeSync>
      </QueryClientProvider>
    </Provider>
  );
}
