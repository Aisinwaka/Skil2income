import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BottomNav } from "@/components/shared/bottom-nav";
import { PageTransition } from "@/components/shared/page-transition";

const costs = [
  { label: "Fabric", amount: "₦36k", pct: 45, color: "bg-emerald" },
  { label: "Sewing tools", amount: "₦22k", pct: 28, color: "bg-blue" },
  { label: "Marketing", amount: "₦14k", pct: 17, color: "bg-orange" },
  { label: "Buffer", amount: "₦8k", pct: 10, color: "bg-muted-2" },
];

const swot = [
  { label: "Strengths", tint: "bg-emerald-tint text-emerald-dark", text: "Skilled tailoring, existing Instagram following" },
  { label: "Weaknesses", tint: "bg-orange-tint text-orange-dark", text: "No delivery system yet, single-person capacity" },
  { label: "Opportunities", tint: "bg-blue-tint text-blue-dark", text: "Rising demand for custom Ankara wear" },
  { label: "Threats", tint: "bg-bg text-muted", text: "Fabric price inflation, seasonal demand dips" },
];

const canvas = [
  { label: "Value Prop", text: "Made-to-fit Ankara, 5-day turnaround" },
  { label: "Customers", text: "Women 22–40, Kaduna & Lagos" },
  { label: "Channels", text: "Instagram, WhatsApp Business" },
  { label: "Revenue", text: "Per-piece sales, deposit + balance" },
];

export default function BusinessPage() {
  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="flex-1 px-5 pt-4">
          <h1 className="font-display text-xl font-extrabold">BusinessAI</h1>
          <p className="mt-1 text-[12.5px] text-muted">
            Turn your tailoring skill into a costed, structured business.
          </p>

          <Card className="mt-3.5">
            <label className="text-[11.5px] font-bold text-muted">YOUR IDEA</label>
            <p className="mt-1.5 text-[13.5px]">
              &ldquo;Custom Ankara outfits sold via Instagram, made to order.&rdquo;
            </p>
            <div className="mt-3 flex gap-2">
              <Badge variant="blue">Budget: ₦80,000</Badge>
              <Badge variant="emerald">Fashion</Badge>
            </div>
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Startup cost breakdown
          </span>
          <Card className="flex flex-col gap-3">
            {costs.map((c) => (
              <div key={c.label} className="flex items-center gap-2.5">
                <span className="w-[74px] text-xs">{c.label}</span>
                <Progress value={c.pct} colorClass={c.color} />
                <span className="tabular-nums w-10 text-right text-[11.5px] font-bold">{c.amount}</span>
              </div>
            ))}
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            SWOT analysis
          </span>
          <div className="grid grid-cols-2 gap-2">
            {swot.map((s) => (
              <div key={s.label} className={`rounded-xl p-2.5 text-[11.5px] leading-relaxed ${s.tint}`}>
                <b>{s.label}</b>
                <br />
                {s.text}
              </div>
            ))}
          </div>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Business model canvas
          </span>
          <div className="grid grid-cols-2 gap-2">
            {canvas.map((c) => (
              <div key={c.label} className="rounded-[10px] border border-dashed border-border p-2.5 text-[11px]">
                <b className="mb-1 block text-[10.5px] uppercase tracking-wide text-muted-2">
                  {c.label}
                </b>
                {c.text}
              </div>
            ))}
          </div>

          <Card className="mt-4.5 mt-[18px] flex items-center justify-between">
            <div>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
                Break-even
              </div>
              <b className="text-lg">4 months</b>
            </div>
            <svg width="90" height="34" viewBox="0 0 90 34">
              <polyline
                points="0,30 20,26 40,18 60,10 80,4"
                fill="none"
                stroke="var(--emerald)"
                strokeWidth="3"
              />
            </svg>
          </Card>

          <Button block className="mb-6 mt-[18px]">
            Export Full Plan (PDF)
          </Button>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
