import { Plus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BottomNav } from "@/components/shared/bottom-nav";
import { PageTransition } from "@/components/shared/page-transition";
import { formatNaira } from "@/lib/utils";

export default function FinancePage() {
  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="relative flex-1 px-5 pt-4">
          <h1 className="font-display text-xl font-extrabold">FinanceAI</h1>
          <p className="mt-1 text-[12.5px] text-muted">June overview</p>

          <Card className="mt-3.5 flex items-center gap-4.5 gap-[18px]">
            <svg width="96" height="96" viewBox="0 0 36 36">
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="var(--bg)" strokeWidth="4" />
              <circle
                cx="18" cy="18" r="15.9" fill="none" stroke="var(--emerald)" strokeWidth="4"
                strokeDasharray="40 60" strokeDashoffset="25" transform="rotate(-90 18 18)"
              />
              <circle
                cx="18" cy="18" r="15.9" fill="none" stroke="var(--blue)" strokeWidth="4"
                strokeDasharray="28 72" strokeDashoffset="-15" transform="rotate(-90 18 18)"
              />
              <circle
                cx="18" cy="18" r="15.9" fill="none" stroke="var(--orange)" strokeWidth="4"
                strokeDasharray="18 82" strokeDashoffset="-43" transform="rotate(-90 18 18)"
              />
            </svg>
            <div className="flex-1">
              {[
                ["Materials", "₦40k", "text-emerald"],
                ["Transport", "₦28k", "text-blue"],
                ["Feeding", "₦18k", "text-orange"],
              ].map(([label, amt, color]) => (
                <div key={label} className="mb-1.5 flex justify-between text-[11.5px] last:mb-0">
                  <span>
                    <span className={color}>●</span> {label}
                  </span>
                  <span className="tabular-nums font-bold">{amt}</span>
                </div>
              ))}
            </div>
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Savings goal
          </span>
          <Card>
            <div className="flex justify-between">
              <b className="text-[13.5px]">Emergency Fund</b>
              <span className="tabular-nums text-xs text-muted">
                {formatNaira(45000)} / {formatNaira(150000)}
              </span>
            </div>
            <Progress value={30} className="mt-2.5" />
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Income forecast
          </span>
          <Card>
            <div className="flex items-center justify-between">
              <div>
                <b className="text-xl text-emerald">{formatNaira(142000)}</b>
                <div className="text-[11px] text-muted">Projected next month</div>
              </div>
              <Badge variant="emerald">+12%</Badge>
            </div>
            <svg
              width="100%" height="36" viewBox="0 0 100 36" preserveAspectRatio="none" className="mt-2"
            >
              <polyline
                points="0,30 16,26 32,28 48,18 64,20 80,10 100,6"
                fill="none" stroke="var(--emerald)" strokeWidth="2.5"
              />
            </svg>
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Recent transactions
          </span>
          <Card className="mb-2 flex justify-between px-3.5 py-3">
            <span className="text-[13px]">Ankara fabric — Kantin Kwari</span>
            <span className="tabular-nums text-[13px] font-bold text-orange-dark">−₦12,000</span>
          </Card>
          <Card className="mb-6 flex justify-between px-3.5 py-3">
            <span className="text-[13px]">Client payment — order #204</span>
            <span className="tabular-nums text-[13px] font-bold text-emerald-dark">+₦35,000</span>
          </Card>

          <button className="absolute bottom-[100px] right-5 flex h-[52px] w-[52px] items-center justify-center rounded-full bg-emerald text-white shadow-lg">
            <Plus size={22} />
          </button>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
