"use client";

import { useState } from "react";
import { Search } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BottomNav } from "@/components/shared/bottom-nav";
import { PageTransition } from "@/components/shared/page-transition";
import { formatNaira, cn } from "@/lib/utils";

const filters = ["All (24)", "Remote", "Kano", "Entry-level", "Saved"];

const jobs = [
  {
    company: "Konga",
    initial: "K",
    color: "bg-orange",
    title: "Social Media Assistant",
    location: "Remote",
    match: 86,
    salaryMin: 80000,
    salaryMax: 120000,
    matchTint: "bg-emerald-tint text-emerald-dark",
  },
  {
    company: "Paystack",
    initial: "P",
    color: "bg-blue",
    title: "Customer Support Rep",
    location: "Lagos (Hybrid)",
    match: 71,
    salaryMin: 150000,
    salaryMax: 200000,
    matchTint: "bg-blue-tint text-blue-dark",
  },
  {
    company: "Kano State Ministry",
    initial: "A",
    color: "bg-emerald",
    title: "Data Entry Clerk (NYSC)",
    location: "Kano",
    match: 54,
    salaryMin: 33000,
    salaryMax: 45000,
    matchTint: "bg-orange-tint text-orange-dark",
  },
];

export default function JobsPage() {
  const [activeFilter, setActiveFilter] = useState(filters[0]);

  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="px-5 pt-4">
          <h1 className="font-display text-xl font-extrabold">Jobs for you</h1>
          <div className="relative mt-3">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-2" />
            <input
              type="text"
              placeholder="Search roles, companies…"
              className="w-full rounded-xl border-[1.5px] border-border bg-bg py-3 pl-10 pr-3.5 text-sm outline-none focus:border-emerald"
            />
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={cn(
                  "whitespace-nowrap rounded-[11px] border-[1.5px] border-border px-3.5 py-2 text-[12.5px] font-bold",
                  activeFilter === f && "border-ink bg-ink text-bg"
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 px-5 pt-3.5">
          {jobs.map((job) => (
            <Card key={job.title} className="mb-3">
              <div className="flex justify-between">
                <div className="flex gap-2.5">
                  <div
                    className={cn(
                      "flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-[11px] text-sm font-bold text-white",
                      job.color
                    )}
                  >
                    {job.initial}
                  </div>
                  <div>
                    <b className="text-[13.5px]">{job.title}</b>
                    <div className="text-[11.5px] text-muted">
                      {job.company} · {job.location}
                    </div>
                  </div>
                </div>
                <span className={cn("font-display h-fit rounded-[10px] px-2.5 py-1 text-[13px] font-extrabold", job.matchTint)}>
                  {job.match}% match
                </span>
              </div>
              <div className="tabular-nums mt-3 text-[13px] font-bold">
                {formatNaira(job.salaryMin)} – {formatNaira(job.salaryMax)}/mo
              </div>
              <div className="mt-3 flex gap-2">
                <Button variant="secondary" size="sm" className="flex-1">
                  Save
                </Button>
                <Button size="sm" className="flex-1">
                  Apply
                </Button>
              </div>
            </Card>
          ))}
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
