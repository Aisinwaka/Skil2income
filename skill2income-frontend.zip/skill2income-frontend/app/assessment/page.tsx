"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { PageTransition } from "@/components/shared/page-transition";
import { useAppDispatch } from "@/store/hooks";
import { setAnswer } from "@/store/userSlice";
import { cn } from "@/lib/utils";

const TOTAL_STEPS = 12;
const CURRENT_STEP = 4;

const options = [
  { label: "No steady income yet", value: "none" },
  { label: "₦10,000 – ₦50,000", value: "10-50k" },
  { label: "₦50,000 – ₦150,000", value: "50-150k" },
  { label: "Above ₦150,000", value: "150k+" },
];

export default function AssessmentPage() {
  const [selected, setSelected] = useState("10-50k");
  const dispatch = useAppDispatch();
  const router = useRouter();

  function handleContinue() {
    dispatch(setAnswer({ incomeRange: selected }));
    router.push("/dashboard");
  }

  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="px-5 pt-4">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-muted">
              Question {CURRENT_STEP} of {TOTAL_STEPS}
            </span>
            <button className="text-emerald" onClick={() => router.push("/dashboard")}>
              Skip
            </button>
          </div>
          <Progress
            value={(CURRENT_STEP / TOTAL_STEPS) * 100}
            className="mt-2"
          />
        </div>

        <div className="flex-1 px-5 pt-6">
          <div className="mb-4 flex gap-2.5">
            <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-blue text-base">
              🤖
            </div>
            <div className="self-start rounded-2xl rounded-bl-md border border-border bg-bg px-3.5 py-2.5 text-sm">
              Let&apos;s understand your finances a bit — this helps me set realistic
              goals with you.
            </div>
          </div>

          <h1 className="font-display mb-4 text-xl font-extrabold">
            What&apos;s your current monthly income?
          </h1>

          <div className="flex flex-col gap-2.5">
            {options.map((opt) => {
              const active = selected === opt.value;
              return (
                <button
                  key={opt.value}
                  onClick={() => setSelected(opt.value)}
                  className={cn(
                    "flex items-center justify-between rounded-[20px] border p-3.5 text-left text-sm font-semibold transition-colors",
                    active
                      ? "border-emerald bg-emerald-tint text-emerald-dark"
                      : "border-border bg-surface"
                  )}
                >
                  {opt.label}
                  <span className={active ? "text-emerald" : "text-muted-2"}>
                    {active ? "●" : "○"}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-7">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
              Coming up next
            </span>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">
              Skills & experience → Internet access & devices → Career goals →
              Availability
            </p>
          </div>
        </div>

        <div className="flex gap-2.5 border-t border-border px-5 py-4">
          <Button variant="secondary" className="flex-1" onClick={() => router.back()}>
            Back
          </Button>
          <Button className="flex-[2]" onClick={handleContinue}>
            Continue →
          </Button>
        </div>
      </div>
    </PageTransition>
  );
}
