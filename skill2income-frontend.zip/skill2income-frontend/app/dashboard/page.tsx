"use client";

import { Bell, FileText, Briefcase, MessageCircle, Wallet, Check } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Gauge } from "@/components/shared/gauge";
import { BottomNav } from "@/components/shared/bottom-nav";
import { PageTransition } from "@/components/shared/page-transition";
import { useAppSelector } from "@/store/hooks";

export default function DashboardPage() {
  const { name, location, readinessScore } = useAppSelector((s) => s.user);

  return (
    <PageTransition>
      <div className="mx-auto flex w-full max-w-[480px] flex-1 flex-col">
        <div className="flex-1 px-5 pt-4">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-[15px] font-bold">Sannu, {name} 👋</div>
              <div className="text-xs text-muted">Tuesday, {location}</div>
            </div>
            <div className="relative">
              <Bell size={20} />
              <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-orange" />
            </div>
          </div>

          <Card className="border-none bg-gradient-to-br from-ink to-[#1E293B] text-white">
            <div className="flex items-center gap-4">
              <Gauge score={readinessScore} size={90} />
              <div>
                <div className="text-xs font-bold uppercase tracking-wider opacity-70">
                  Income Readiness
                </div>
                <div className="mt-1 text-sm font-bold">Good progress, {name}</div>
                <div className="mt-1 text-[11.5px] opacity-75">
                  Portfolio & networking need work
                </div>
              </div>
            </div>
          </Card>

          <span className="mb-2 mt-4.5 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Your roadmap
          </span>
          <Card>
            <div className="flex items-center justify-between">
              <b className="text-sm">Path: Digital Marketing Assistant</b>
              <Badge variant="emerald">Month 2/6</Badge>
            </div>
            <div className="mt-3 flex flex-col gap-2.5 text-[12.5px]">
              <div className="flex items-center gap-2">
                <Check size={14} className="text-emerald" /> Complete social media
                basics course
              </div>
              <div className="flex items-center gap-2">
                <Check size={14} className="text-emerald" /> Build 3-piece portfolio
              </div>
              <div className="flex items-center gap-2 font-bold">
                <span className="h-3.5 w-3.5 rounded-full border-2 border-blue" />
                Apply to 5 matched jobs
              </div>
            </div>
          </Card>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Today&apos;s tasks
          </span>
          <Card className="flex flex-col gap-3">
            <label className="flex items-center gap-2.5 text-[13px]">
              <input type="checkbox" defaultChecked className="h-[18px] w-[18px] accent-emerald" />
              <span className="text-muted-2 line-through">15-min lesson: Canva basics</span>
            </label>
            <label className="flex items-center gap-2.5 text-[13px]">
              <input type="checkbox" className="h-[18px] w-[18px] accent-emerald" />
              Message AI Mentor about interview prep
            </label>
            <label className="flex items-center gap-2.5 text-[13px]">
              <input type="checkbox" className="h-[18px] w-[18px] accent-emerald" />
              Log this week&apos;s income & expenses
            </label>
          </Card>

          <div className="mt-4 grid grid-cols-2 gap-3">
            <Card>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
                Learning
              </div>
              <b className="my-1.5 block text-xl">62%</b>
              <Progress value={62} colorClass="bg-blue" />
            </Card>
            <Card>
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
                Income growth
              </div>
              <b className="my-1.5 block text-xl text-emerald">+18%</b>
              <svg width="100%" height="28" viewBox="0 0 100 28" preserveAspectRatio="none">
                <polyline
                  points="0,24 20,20 40,22 60,12 80,14 100,4"
                  fill="none"
                  stroke="var(--emerald)"
                  strokeWidth="3"
                />
              </svg>
            </Card>
          </div>

          <span className="mb-2 mt-[18px] block text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Recommended jobs
          </span>
          <Card className="flex items-center justify-between">
            <div>
              <b className="text-[13.5px]">Social Media Assistant</b>
              <div className="text-[11.5px] text-muted">Konga · Remote · ₦80k–₦120k</div>
            </div>
            <Badge variant="emerald">86%</Badge>
          </Card>

          <Card className="mt-3.5 flex items-center gap-3 border-none bg-blue-tint">
            <span className="text-xl">🤖</span>
            <div>
              <b className="text-[13px] text-blue-dark">Ask your AI Mentor</b>
              <div className="text-[11.5px] text-blue-dark opacity-80">
                &ldquo;How do I follow up after applying?&rdquo;
              </div>
            </div>
          </Card>

          <div className="mt-4.5 mt-[18px] grid grid-cols-4 gap-2 pb-6 text-center">
            {[
              [FileText, "CV"],
              [Briefcase, "Jobs"],
              [MessageCircle, "Chat"],
              [Wallet, "Finance"],
            ].map(([Icon, label]) => {
              const IconComp = Icon as React.ElementType;
              return (
                <div key={label as string}>
                  <div className="flex justify-center">
                    <IconComp size={20} />
                  </div>
                  <div className="mt-1 text-[10px] text-muted">{label as string}</div>
                </div>
              );
            })}
          </div>
        </div>
        <BottomNav />
      </div>
    </PageTransition>
  );
}
