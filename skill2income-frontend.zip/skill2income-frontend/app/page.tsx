import Link from "next/link";
import { Play, BarChart3, Map, MessagesSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { TopBar } from "@/components/shared/top-bar";
import { PageTransition } from "@/components/shared/page-transition";

const features = [
  {
    icon: BarChart3,
    bg: "bg-emerald-tint",
    title: "Income Readiness Score",
    desc: "See exactly where you stand across 8 categories.",
  },
  {
    icon: Map,
    bg: "bg-blue-tint",
    title: "Personal Income Blueprint",
    desc: "A month-by-month plan built around your goals.",
  },
  {
    icon: MessagesSquare,
    bg: "bg-orange-tint",
    title: "AI Coach, in your language",
    desc: "English, Hausa, Yoruba, or Igbo — anytime.",
  },
];

const howItWorks = [
  { n: 1, title: "Tell us about you", desc: "A short AI assessment — 5 minutes." },
  { n: 2, title: "Get your Blueprint", desc: "A realistic path, scored and scheduled." },
  { n: 3, title: "Grow your income", desc: "Daily coaching, jobs, and tools that fit you." },
];

const faqs = [
  "Is Skill2Income free?",
  "Do I need a degree to use it?",
  "Which languages are supported?",
];

export default function LandingPage() {
  return (
    <PageTransition>
      <div className="mx-auto w-full max-w-[480px] flex-1">
        <TopBar showMenu />

        <div className="px-5 pb-16 pt-2">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-tint px-3 py-1.5 text-xs font-bold text-emerald-dark">
            ✦ AI-powered economic mobility
          </span>

          <h1 className="font-display mt-3.5 text-[32px] font-extrabold leading-[1.12]">
            From Skills to <span className="text-emerald">Sustainable Income.</span>
          </h1>
          <p className="mt-2.5 text-[14.5px] leading-relaxed text-muted">
            Answer a few questions and get a personal, AI-built roadmap into a job, a
            trade, freelancing, or your own business — made for Nigeria.
          </p>

          <div className="mt-4 flex gap-2.5">
            <Link href="/assessment" className="flex-1">
              <Button block>Start Free</Button>
            </Link>
            <Button variant="secondary" block className="flex-1">
              <Play size={14} /> Watch Demo
            </Button>
          </div>

          <div className="mt-5 flex gap-2.5">
            {[
              ["128K+", "Nigerians onboarded"],
              ["₦2.4B", "income tracked"],
              ["41K", "jobs matched"],
            ].map(([stat, label]) => (
              <div
                key={label}
                className="flex-1 rounded-[14px] border border-border bg-bg p-3 text-center"
              >
                <b className="font-display block text-[18px]">{stat}</b>
                <span className="text-[10.5px] text-muted">{label}</span>
              </div>
            ))}
          </div>

          <hr className="my-5 border-border" />
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Features
          </span>
          <div className="mt-2 flex flex-col divide-y divide-border">
            {features.map(({ icon: Icon, bg, title, desc }) => (
              <div key={title} className="flex items-start gap-3 py-3.5">
                <div className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-[11px] ${bg}`}>
                  <Icon size={18} />
                </div>
                <div>
                  <b className="text-sm">{title}</b>
                  <p className="mt-0.5 text-[12.5px] text-muted">{desc}</p>
                </div>
              </div>
            ))}
          </div>

          <hr className="my-5 border-border" />
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            How it works
          </span>
          <div className="mt-2 flex flex-col gap-3">
            {howItWorks.map(({ n, title, desc }) => (
              <div key={n} className="flex items-start gap-3">
                <div className="font-display flex h-[30px] w-[30px] flex-shrink-0 items-center justify-center rounded-[9px] bg-ink text-[13px] font-extrabold text-bg">
                  {n}
                </div>
                <div>
                  <b className="text-[13.5px]">{title}</b>
                  <p className="text-[12px] text-muted">{desc}</p>
                </div>
              </div>
            ))}
          </div>

          <hr className="my-5 border-border" />
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            Testimonial
          </span>
          <Card className="mt-2.5">
            <p className="text-[13.5px] leading-relaxed">
              &ldquo;I didn&apos;t know my tailoring could be a real business until
              BusinessAI broke down the numbers for me. I now earn more than my old
              office job.&rdquo;
            </p>
            <div className="mt-3 flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-orange text-sm font-bold text-white">
                F
              </div>
              <div>
                <b className="text-[13px]">Fatima B.</b>
                <div className="text-[11.5px] text-muted">Kaduna State</div>
              </div>
            </div>
          </Card>

          <div className="mt-6 flex items-center justify-between text-xs font-bold text-muted opacity-60">
            <span>NYSC</span>
            <span>FMYSD</span>
            <span>Tony Elumelu Fdn</span>
            <span>3MTT</span>
          </div>

          <hr className="my-5 border-border" />
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-muted-2">
            FAQ
          </span>
          <div className="mt-1 flex flex-col divide-y divide-border">
            {faqs.map((q) => (
              <div key={q} className="flex items-center justify-between py-3.5 text-sm font-bold">
                {q} <span className="text-muted">+</span>
              </div>
            ))}
          </div>

          <div className="mt-8 text-center text-[11.5px] text-muted">
            © 2026 Skill2Income · Made for Nigeria 🇳🇬
          </div>
        </div>
      </div>
    </PageTransition>
  );
}
