import { cn } from "@/lib/utils";

export function Progress({
  value,
  colorClass = "bg-emerald",
  className,
}: {
  value: number;
  colorClass?: string;
  className?: string;
}) {
  return (
    <div className={cn("h-[9px] w-full rounded-full bg-bg overflow-hidden", className)}>
      <div
        className={cn("h-full rounded-full transition-all duration-500", colorClass)}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}
