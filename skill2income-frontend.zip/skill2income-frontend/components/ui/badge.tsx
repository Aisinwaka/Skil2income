import { HTMLAttributes } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11.5px] font-bold",
  {
    variants: {
      variant: {
        emerald: "bg-emerald-tint text-emerald-dark",
        blue: "bg-blue-tint text-blue-dark",
        orange: "bg-orange-tint text-orange-dark",
        neutral: "bg-bg text-muted",
      },
    },
    defaultVariants: { variant: "emerald" },
  }
);

export interface BadgeProps
  extends HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
