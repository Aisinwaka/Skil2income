import { ButtonHTMLAttributes, forwardRef } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 rounded-xl font-bold font-body text-sm transition-transform active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none",
  {
    variants: {
      variant: {
        primary: "bg-emerald text-white hover:bg-emerald-dark",
        secondary: "bg-surface text-ink border-[1.5px] border-border",
        ghost: "bg-transparent text-ink hover:bg-border/40",
        outline: "bg-transparent border-[1.5px] border-emerald text-emerald-dark",
      },
      size: {
        default: "px-5 py-3.5",
        sm: "px-3.5 py-2 text-[13px] rounded-lg",
        icon: "h-10 w-10 rounded-full p-0",
      },
      block: {
        true: "w-full",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, block, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size, block }), className)}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
