"use client";

import { Moon, Sun, Menu } from "lucide-react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { toggleTheme } from "@/store/uiSlice";

export function TopBar({ showMenu = false }: { showMenu?: boolean }) {
  const dispatch = useAppDispatch();
  const theme = useAppSelector((s) => s.ui.theme);

  return (
    <div className="flex items-center justify-between px-5 py-3">
      <div className="flex items-center gap-2 font-display text-[16px] font-extrabold">
        <div className="relative h-6 w-6 flex-shrink-0 rounded-[7px] bg-gradient-to-br from-emerald to-blue">
          <span className="absolute inset-0 flex items-center justify-center text-[12px] font-extrabold text-white">
            ₦
          </span>
        </div>
        Skill2Income
      </div>
      <div className="flex items-center gap-2">
        <button
          onClick={() => dispatch(toggleTheme())}
          aria-label="Toggle theme"
          className="flex h-9 w-9 items-center justify-center rounded-[11px] border border-border bg-surface"
        >
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </button>
        {showMenu && (
          <button className="flex h-9 w-9 items-center justify-center rounded-[11px] border border-border bg-surface">
            <Menu size={16} />
          </button>
        )}
      </div>
    </div>
  );
}
