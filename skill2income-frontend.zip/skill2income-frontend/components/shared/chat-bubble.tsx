import { cn } from "@/lib/utils";

export function ChatBubble({
  from,
  children,
}: {
  from: "ai" | "user";
  children: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        "max-w-[78%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed",
        from === "ai"
          ? "self-start rounded-bl-md border border-border bg-bg"
          : "self-end rounded-br-md bg-emerald text-white"
      )}
    >
      {children}
    </div>
  );
}
