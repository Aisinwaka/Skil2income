"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Briefcase, MessageCircle, LineChart, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { href: "/dashboard", label: "Home", icon: Home },
  { href: "/jobs", label: "Jobs", icon: Briefcase },
  { href: "/chat", label: "Chat", icon: MessageCircle },
  { href: "/finance", label: "Income", icon: LineChart },
  { href: "/business", label: "Business", icon: Wallet },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="sticky bottom-0 z-30 flex justify-around border-t border-border bg-surface px-1.5 pb-3.5 pt-2.5">
      {items.map(({ href, label, icon: Icon }) => {
        const active = pathname === href;
        return (
          <Link
            key={href}
            href={href}
            className={cn(
              "flex flex-col items-center gap-1 text-[9.5px] font-bold",
              active ? "text-emerald" : "text-muted-2"
            )}
          >
            <Icon size={18} strokeWidth={2.4} />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
