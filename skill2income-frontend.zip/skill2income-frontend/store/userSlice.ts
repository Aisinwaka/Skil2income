import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export interface AssessmentAnswers {
  incomeRange?: string;
  skills?: string[];
  goal?: string;
}

interface UserState {
  name: string;
  location: string;
  readinessScore: number;
  answers: AssessmentAnswers;
}

const initialState: UserState = {
  name: "Amina",
  location: "Kano State",
  readinessScore: 68,
  answers: {},
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setAnswer(state, action: PayloadAction<Partial<AssessmentAnswers>>) {
      state.answers = { ...state.answers, ...action.payload };
    },
    setReadinessScore(state, action: PayloadAction<number>) {
      state.readinessScore = action.payload;
    },
  },
});

export const { setAnswer, setReadinessScore } = userSlice.actions;
export default userSlice.reducer;
