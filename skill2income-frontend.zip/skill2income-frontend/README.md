# Skill2Income — Frontend

Phase 3 deliverable: a real, working Next.js 16 (App Router) frontend implementing
the 8 core screens from the UI/UX prototype, wired up with actual routing, state
management, and component architecture — ready to build on for the real backend.

## Stack

- **Next.js 16** (App Router, Turbopack) + **TypeScript**
- **Tailwind CSS v4** — brand tokens (emerald / blue / orange, light & dark mode)
  defined in `app/globals.css` as CSS variables, exposed as Tailwind utilities
- **Redux Toolkit** (`store/`) — theme state + user/assessment state
- **TanStack React Query** — wired up via `app/providers.tsx`, ready for real API calls
- **Framer Motion** — page-transition animation wrapper (`components/shared/page-transition.tsx`)
- **lucide-react** — icon set
- PWA-ready: `public/manifest.json` + placeholder icons

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`. Routes:

| Route          | Screen                          |
|----------------|----------------------------------|
| `/`            | Landing page                    |
| `/login`       | Login (phone/OTP + Google)      |
| `/assessment`  | AI Assessment flow               |
| `/dashboard`   | Dashboard                        |
| `/chat`        | AI Chat Assistant                |
| `/jobs`        | Jobs module                      |
| `/business`    | BusinessAI                       |
| `/finance`     | FinanceAI                        |

## Project structure

```
app/
  layout.tsx          Root layout — fonts, providers, metadata
  providers.tsx        Redux + React Query providers, theme sync
  globals.css           Design tokens (colors, shadows, fonts) as CSS vars
  page.tsx              Landing
  login/page.tsx
  assessment/page.tsx
  dashboard/page.tsx
  chat/page.tsx
  jobs/page.tsx
  business/page.tsx
  finance/page.tsx
components/
  ui/                  Reusable primitives: Button, Card, Badge, Progress
  shared/              Gauge, ChatBubble, BottomNav, TopBar, PageTransition
store/
  store.ts, hooks.ts, uiSlice.ts, userSlice.ts
```

## Design tokens

All brand colors, spacing, radii, and shadows live in `app/globals.css` under
`:root` / `.dark`, then get exposed to Tailwind via `@theme inline`. Change a
value once (e.g. `--emerald`) and it updates everywhere — buttons, badges,
gauges, charts.

Dark mode is class-based (`<html class="dark">`), toggled via the Redux `ui`
slice and synced automatically in `app/providers.tsx`.

## What's mocked vs. real

This phase is frontend-only, so:

- All data (jobs, scores, transactions, chat replies) is static/mock data in
  each page component — no backend calls yet.
- The AI Chat page has simple client-side state to simulate sending a message;
  swap the `setTimeout` reply in `app/chat/page.tsx` for a real API/streaming
  call when the AI service is ready.
- Redux `userSlice` holds assessment answers and the readiness score — replace
  the static default with a real fetch once auth + backend exist.
- React Query is installed and wired up (`app/providers.tsx`) but not yet used
  for a real request — add your API hooks in a `lib/api/` folder as the
  backend comes online.

## Next steps (Phase 4+)

- Connect `/assessment` submission and `/login` OTP flow to real auth endpoints.
- Replace mock arrays in `jobs`, `chat`, `business`, `finance` pages with
  React Query hooks hitting the Jobs/AI/Finance services.
- Add a service worker (e.g. `next-pwa` or `@ducanh2912/next-pwa`) for full
  offline support — the manifest is already in place.
- Add authentication guards / middleware once the Auth service exists so
  `/dashboard`, `/chat`, `/jobs`, `/business`, `/finance` require a session.

## Deploying

Zero-config on Vercel — see the top-level `DEPLOYMENT.md` (shipped alongside
this project) for exact commands. **Note:** this frontend currently renders
mock data hard-coded in each page component; it isn't calling the backend or
AI service yet. It'll deploy and look/work identically to running it
locally, but won't reflect real backend data until that wiring is added.

## Testing

```bash
npm test              # run once
npm run test:watch     # watch mode
npm run test:coverage   # with coverage report
```

37 tests across 9 files (Vitest + React Testing Library + jsdom), covering
the UI primitives (`Button`, `Card`, `Badge`, `Progress`), the `Gauge` (SVG
arc math for the Income Readiness Score), `ChatBubble` styling, `BottomNav`
active-route highlighting (with `next/navigation` mocked), the Redux slices
(`uiSlice`, `userSlice`), and the `lib/utils` helpers (`cn`, `formatNaira`).

This phase focuses on components and state — not full page/route tests,
since the pages are still mostly static/mock content (see "What's mocked vs.
real" below). Once pages are wired to the real backend, add page-level tests
with mocked `fetch`/React Query responses.

## Build

```bash
npm run build
npm run start
```

> Note: this build requires internet access to fetch Plus Jakarta Sans and
> Inter from Google Fonts via `next/font/google`. If you're building in an
> offline/sandboxed environment, those fonts gracefully fall back to system
> fonts instead of failing.
