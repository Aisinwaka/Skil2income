def test_opportunities_rank_orders_by_relevance(client):
    payload = {
        "user_profile_text": "recent graduate looking for AI and machine learning training programs",
        "opportunities": [
            {
                "id": "o1",
                "title": "3MTT AI & Machine Learning Fellowship",
                "type": "scholarship",
                "eligibility": "Nigerian residents, basic digital literacy",
            },
            {
                "id": "o2",
                "title": "NYSC SAED",
                "type": "nysc",
                "eligibility": "Current NYSC corps members",
            },
        ],
        "top_k": 5,
    }
    res = client.post("/opportunities/rank", json=payload)
    assert res.status_code == 200
    results = res.json()["results"]
    assert len(results) == 2
    # results sorted descending by relevance_score
    assert results[0]["relevance_score"] >= results[1]["relevance_score"]
    # The AI/ML fellowship should be most relevant to this profile text
    assert results[0]["opportunity_id"] == "o1"


def test_opportunities_rank_empty_list(client):
    payload = {"user_profile_text": "anything", "opportunities": [], "top_k": 5}
    res = client.post("/opportunities/rank", json=payload)
    assert res.status_code == 200
    assert res.json()["results"] == []


def test_business_recommend_returns_fallback_without_api_key(client):
    payload = {
        "idea": "Custom Ankara outfits sold via Instagram",
        "budget_naira": 80000,
        "user_skills": ["tailoring", "instagram marketing"],
    }
    res = client.post("/business/recommend", json=payload)
    assert res.status_code == 200
    body = res.json()
    assert 0 <= body["viability_score"] <= 100
    assert len(body["reasoning"]) > 0
    assert len(body["suggested_focus"]) > 0


def test_business_recommend_higher_budget_increases_score(client):
    low = client.post("/business/recommend", json={
        "idea": "Small kiosk", "budget_naira": 10000, "user_skills": [],
    }).json()
    high = client.post("/business/recommend", json={
        "idea": "Small kiosk", "budget_naira": 200000, "user_skills": ["sales", "inventory"],
    }).json()
    assert high["viability_score"] > low["viability_score"]


def test_business_recommend_rejects_non_positive_budget(client):
    res = client.post("/business/recommend", json={
        "idea": "Idea", "budget_naira": 0, "user_skills": [],
    })
    assert res.status_code == 422
