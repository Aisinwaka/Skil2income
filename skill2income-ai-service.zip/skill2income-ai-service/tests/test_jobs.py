def test_health(client):
    res = client.get("/health")
    assert res.status_code == 200
    body = res.json()
    assert body["status"] == "ok"
    assert body["service"] == "skill2income-ai-service"
    assert "ai_model_configured" in body


def test_match_jobs_ranks_better_skill_overlap_higher(client):
    payload = {
        "user_skills": ["social media", "canva", "customer service"],
        "user_goals": "Land a digital marketing role",
        "jobs": [
            {
                "id": "j1",
                "title": "Social Media Assistant",
                "description": "Manage social media calendar and respond to comments",
                "skills_required": ["social media", "canva", "copywriting"],
            },
            {
                "id": "j2",
                "title": "Backend Engineer",
                "description": "Build APIs with Node.js and Postgres",
                "skills_required": ["node.js", "postgresql", "docker"],
            },
        ],
        "top_k": 5,
    }
    res = client.post("/match/jobs", json=payload)
    assert res.status_code == 200
    results = res.json()["results"]
    assert len(results) == 2

    # Results must be sorted descending by match_score
    assert results[0]["match_score"] >= results[1]["match_score"]
    # The social-media job should clearly outrank the backend job for this user
    by_id = {r["job_id"]: r for r in results}
    assert by_id["j1"]["match_score"] > by_id["j2"]["match_score"]
    assert "canva" in by_id["j1"]["matched_skills"]
    assert "copywriting" in by_id["j1"]["missing_skills"]
    assert by_id["j2"]["matched_skills"] == []


def test_match_jobs_respects_top_k(client):
    jobs = [
        {"id": f"j{i}", "title": f"Job {i}", "description": "desc", "skills_required": ["excel"]}
        for i in range(5)
    ]
    payload = {"user_skills": ["excel"], "user_goals": "", "jobs": jobs, "top_k": 2}
    res = client.post("/match/jobs", json=payload)
    assert res.status_code == 200
    assert len(res.json()["results"]) == 2


def test_match_jobs_empty_jobs_list(client):
    payload = {"user_skills": ["excel"], "user_goals": "", "jobs": [], "top_k": 5}
    res = client.post("/match/jobs", json=payload)
    assert res.status_code == 200
    assert res.json()["results"] == []


def test_match_jobs_missing_required_field_returns_422(client):
    # user_skills is required — omitting it should trigger Pydantic validation
    res = client.post("/match/jobs", json={"jobs": [], "user_goals": ""})
    assert res.status_code == 422
