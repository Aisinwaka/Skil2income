def test_skill_gap_no_gap(client):
    payload = {
        "user_skills": ["excel", "attention to detail"],
        "target_role": "Data Entry Clerk",
        "target_skills": ["excel", "attention to detail"],
    }
    res = client.post("/skill-gap", json=payload)
    assert res.status_code == 200
    body = res.json()
    assert body["gap_score"] == 0
    assert body["missing_skills"] == []
    assert "already have every skill" in body["recommendation"]


def test_skill_gap_partial_gap(client):
    payload = {
        "user_skills": ["social media", "canva"],
        "target_role": "Digital Marketing Assistant",
        "target_skills": ["social media", "canva", "copywriting", "google analytics"],
    }
    res = client.post("/skill-gap", json=payload)
    assert res.status_code == 200
    body = res.json()
    assert body["gap_score"] == 50
    assert set(body["missing_skills"]) == {"copywriting", "google analytics"}
    assert set(body["matched_skills"]) == {"social media", "canva"}


def test_skill_gap_full_gap(client):
    payload = {
        "user_skills": ["cooking"],
        "target_role": "Backend Engineer",
        "target_skills": ["node.js", "postgresql", "docker"],
    }
    res = client.post("/skill-gap", json=payload)
    assert res.status_code == 200
    body = res.json()
    assert body["gap_score"] == 100
    assert body["matched_skills"] == []
    assert "Significant gap" in body["recommendation"]


def test_skill_gap_case_insensitive_matching(client):
    payload = {
        "user_skills": ["Excel", "EXCEL formulas"],
        "target_role": "Clerk",
        "target_skills": ["excel"],
    }
    res = client.post("/skill-gap", json=payload)
    assert res.status_code == 200
    assert "excel" in res.json()["matched_skills"]
