def test_chat_returns_fallback_without_api_key(client):
    # No ANTHROPIC_API_KEY is set in the test environment, so this must hit
    # the fallback path rather than erroring.
    payload = {
        "message": "How do I price my tailoring work?",
        "language": "en",
        "history": [],
    }
    res = client.post("/chat", json=payload)
    assert res.status_code == 200
    body = res.json()
    assert isinstance(body["reply"], str) and len(body["reply"]) > 0
    assert isinstance(body["retrieved_context"], list)


def test_chat_retrieves_relevant_knowledge_base_entry(client):
    payload = {
        "message": "How should I price my freelance work as a beginner?",
        "language": "en",
        "history": [],
    }
    res = client.post("/chat", json=payload)
    assert res.status_code == 200
    body = res.json()
    # Should retrieve the freelance pricing knowledge-base entry
    assert any("undercharge" in snippet or "pric" in snippet.lower() for snippet in body["retrieved_context"])


def test_chat_accepts_conversation_history(client):
    payload = {
        "message": "What about NYSC?",
        "language": "en",
        "history": [
            {"role": "user", "content": "Tell me about training programs"},
            {"role": "assistant", "content": "There are several options depending on your goals."},
        ],
    }
    res = client.post("/chat", json=payload)
    assert res.status_code == 200


def test_chat_rejects_invalid_role_in_history(client):
    payload = {
        "message": "Hello",
        "language": "en",
        "history": [{"role": "system", "content": "not allowed"}],
    }
    res = client.post("/chat", json=payload)
    assert res.status_code == 422


def test_chat_rejects_unsupported_language(client):
    payload = {"message": "Hello", "language": "fr", "history": []}
    res = client.post("/chat", json=payload)
    assert res.status_code == 422
