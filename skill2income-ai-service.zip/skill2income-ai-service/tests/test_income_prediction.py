BASE_PAYLOAD = {
    "education_level": "secondary",
    "digital_skills_count": 0,
    "experience_years": 0,
    "portfolio_items": 0,
    "internet_access": "limited",
    "network_size": "small",
}


def test_income_predict_returns_full_shape(client):
    res = client.post("/income/predict", json=BASE_PAYLOAD)
    assert res.status_code == 200
    body = res.json()
    assert body["predicted_monthly_income"] > 0
    assert body["income_range_low"] < body["predicted_monthly_income"] < body["income_range_high"]
    assert len(body["top_factors"]) == 6
    assert all("factor" in f and "contribution_naira" in f for f in body["top_factors"])
    assert "explanation" in body


def test_income_predict_higher_education_increases_prediction(client):
    low = client.post("/income/predict", json={**BASE_PAYLOAD, "education_level": "none"}).json()
    high = client.post("/income/predict", json={**BASE_PAYLOAD, "education_level": "msc_plus"}).json()
    assert high["predicted_monthly_income"] > low["predicted_monthly_income"]


def test_income_predict_more_experience_increases_prediction(client):
    junior = client.post("/income/predict", json={**BASE_PAYLOAD, "experience_years": 0}).json()
    senior = client.post("/income/predict", json={**BASE_PAYLOAD, "experience_years": 10}).json()
    assert senior["predicted_monthly_income"] > junior["predicted_monthly_income"]


def test_income_predict_more_digital_skills_increases_prediction(client):
    few = client.post("/income/predict", json={**BASE_PAYLOAD, "digital_skills_count": 0}).json()
    many = client.post("/income/predict", json={**BASE_PAYLOAD, "digital_skills_count": 8}).json()
    assert many["predicted_monthly_income"] > few["predicted_monthly_income"]


def test_income_predict_never_below_floor(client):
    # Worst-case inputs should still clamp to the floor, never negative/zero
    worst = {
        "education_level": "none",
        "digital_skills_count": 0,
        "experience_years": 0,
        "portfolio_items": 0,
        "internet_access": "none",
        "network_size": "small",
    }
    res = client.post("/income/predict", json=worst)
    assert res.status_code == 200
    assert res.json()["predicted_monthly_income"] >= 10000


def test_income_predict_invalid_enum_returns_422(client):
    res = client.post("/income/predict", json={**BASE_PAYLOAD, "internet_access": "fiber-optic"})
    assert res.status_code == 422
