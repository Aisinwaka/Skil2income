"""
Synthetic training data for the Income Prediction model.

There's no real historical income dataset available yet (the platform hasn't
launched), so this generates a plausible synthetic dataset using weighted
feature relationships grounded in the PRD's assessment categories, with noise
added for realism. This lets us ship a real, trained scikit-learn regression
model today with an honest, documented path to retraining on real user data
(see README) once it exists.
"""

import numpy as np

FEATURE_NAMES = [
    "education_score",     # 0-100 (mapped from education level)
    "digital_skills_count", # number of self-reported digital skills
    "experience_years",
    "portfolio_items",
    "internet_score",       # 0-100 (none=15, limited=50, stable=90)
    "network_score",        # 0-100 (small=30, medium=60, large=90)
]


def generate_synthetic_dataset(n_samples: int = 2000, seed: int = 42):
    rng = np.random.default_rng(seed)

    education_score = rng.choice([20, 30, 50, 65, 80, 95], size=n_samples)
    digital_skills_count = rng.integers(0, 8, size=n_samples)
    experience_years = rng.integers(0, 12, size=n_samples)
    portfolio_items = rng.integers(0, 6, size=n_samples)
    internet_score = rng.choice([15, 50, 90], size=n_samples)
    network_score = rng.choice([30, 60, 90], size=n_samples)

    X = np.column_stack([
        education_score,
        digital_skills_count,
        experience_years,
        portfolio_items,
        internet_score,
        network_score,
    ])

    # Ground-truth relationship (naira/month), loosely modeled on Nigerian
    # entry-to-mid-level income patterns, plus Gaussian noise.
    base = 15000
    y = (
        base
        + education_score * 550
        + digital_skills_count * 6000
        + experience_years * 4500
        + portfolio_items * 3500
        + internet_score * 300
        + network_score * 250
        + rng.normal(0, 12000, size=n_samples)
    )
    y = np.clip(y, 10000, 600000)

    return X, y
