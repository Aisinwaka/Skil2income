from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

from app.models.schemas import (
    MatchJobsRequest, MatchJobsResponse,
    SkillGapRequest, SkillGapResponse,
    IncomePredictRequest, IncomePredictResponse,
    RecommendOpportunitiesRequest, RecommendOpportunitiesResponse,
    ChatRequest, ChatResponse,
    BusinessRecommendRequest, BusinessRecommendResponse,
)
from app.services.job_matching import match_jobs
from app.services.skill_gap import analyze_skill_gap
from app.services.income_prediction import predict_income
from app.services.opportunity_ranking import rank_opportunities
from app.services.chat import generate_reply
from app.services.business_recommend import recommend_business

app = FastAPI(
    title="Skill2Income AI Service",
    description="Career recommendation, skill-gap detection, income prediction, "
                 "opportunity ranking, business recommendation, and conversational AI.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS_ORIGIN", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "skill2income-ai-service",
        "ai_model_configured": bool(os.environ.get("ANTHROPIC_API_KEY")),
    }


@app.post("/match/jobs", response_model=MatchJobsResponse)
def match_jobs_endpoint(req: MatchJobsRequest):
    """Career Recommendation / Job Matching — TF-IDF + skill-overlap ranking."""
    return MatchJobsResponse(results=match_jobs(req))


@app.post("/skill-gap", response_model=SkillGapResponse)
def skill_gap_endpoint(req: SkillGapRequest):
    """Skill Gap Detection against a target role."""
    return analyze_skill_gap(req)


@app.post("/income/predict", response_model=IncomePredictResponse)
def income_predict_endpoint(req: IncomePredictRequest):
    """Income Prediction — trained linear regression with explainable factors."""
    return predict_income(req)


@app.post("/opportunities/rank", response_model=RecommendOpportunitiesResponse)
def opportunities_rank_endpoint(req: RecommendOpportunitiesRequest):
    """Opportunity Ranking — relevance-ranked jobs/grants/scholarships/NYSC/gov programs."""
    return RecommendOpportunitiesResponse(results=rank_opportunities(req))


@app.post("/business/recommend", response_model=BusinessRecommendResponse)
async def business_recommend_endpoint(req: BusinessRecommendRequest):
    """Business Recommendation — viability score + AI-enhanced reasoning."""
    return await recommend_business(req)


@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest):
    """Conversational AI (AI Mentor) — RAG over the knowledge base + Claude."""
    return await generate_reply(req)
