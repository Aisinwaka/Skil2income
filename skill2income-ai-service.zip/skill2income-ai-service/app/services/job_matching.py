"""
Career Recommendation / Job Matching engine.

Approach: TF-IDF vectorization (a classic, fully-offline embedding technique)
over each job's text (title + description + required skills) and the user's
skills + goals, ranked by cosine similarity. This is combined with an
explicit skill-overlap calculation so the match score is explainable, not
just a black-box similarity number — the response always says exactly which
skills matched and which are missing.

Swap-in path: replace `_vectorize` with real sentence embeddings (e.g.
sentence-transformers or an embeddings API) once you want semantic matching
beyond keyword/TF-IDF overlap — the rest of the ranking and explanation logic
is unchanged.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.models.schemas import MatchJobsRequest, JobMatchResult


def _job_text(job) -> str:
    return f"{job.title} {job.description} {' '.join(job.skills_required)}"


def match_jobs(req: MatchJobsRequest) -> list[JobMatchResult]:
    if not req.jobs:
        return []

    user_text = f"{' '.join(req.user_skills)} {req.user_goals}"
    corpus = [user_text] + [_job_text(j) for j in req.jobs]

    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf = vectorizer.fit_transform(corpus)
    similarities = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()

    user_skills_lower = {s.lower().strip() for s in req.user_skills}

    results = []
    for job, sim in zip(req.jobs, similarities):
        job_skills_lower = {s.lower().strip() for s in job.skills_required}
        matched = sorted(job_skills_lower & user_skills_lower)
        missing = sorted(job_skills_lower - user_skills_lower)

        skill_overlap_pct = (
            len(matched) / len(job_skills_lower) * 100 if job_skills_lower else 50.0
        )
        # Blend semantic similarity (TF-IDF cosine) with explicit skill overlap,
        # weighted toward overlap since it's the more reliable, explainable signal.
        match_score = round(0.4 * (sim * 100) + 0.6 * skill_overlap_pct)
        match_score = max(5, min(99, match_score))

        if matched and missing:
            explanation = (
                f"Matches on {', '.join(matched)}; would need {', '.join(missing)} "
                f"to be a stronger fit."
            )
        elif matched:
            explanation = f"Strong match — covers all required skills: {', '.join(matched)}."
        else:
            explanation = (
                f"No direct skill overlap detected; role requires {', '.join(sorted(job_skills_lower)) or 'unspecified skills'}."
            )

        results.append(
            JobMatchResult(
                job_id=job.id,
                title=job.title,
                match_score=match_score,
                matched_skills=matched,
                missing_skills=missing,
                explanation=explanation,
            )
        )

    results.sort(key=lambda r: r.match_score, reverse=True)
    return results[: req.top_k]
