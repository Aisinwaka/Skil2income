"""
Business Recommendation — scores the viability of a business idea given a
budget and the user's skills, and (when an API key is configured) asks Claude
for a short reasoning paragraph and suggested area of focus. Falls back to a
rule-based heuristic so the endpoint always returns something useful.
"""

from app.models.schemas import BusinessRecommendRequest, BusinessRecommendResponse
from app.services.ai_client import call_claude


def _heuristic_score(req: BusinessRecommendRequest) -> int:
    score = 50
    if req.budget_naira >= 50000:
        score += 15
    if req.budget_naira >= 150000:
        score += 10
    if req.user_skills:
        score += min(20, len(req.user_skills) * 5)
    return max(10, min(95, score))


async def recommend_business(req: BusinessRecommendRequest) -> BusinessRecommendResponse:
    score = _heuristic_score(req)

    system = (
        "You are BusinessAI inside Skill2Income, an economic mobility platform for "
        "Nigerians. Given a business idea, a naira budget, and the user's skills, "
        "respond with exactly two short lines: "
        "Line 1 starting with 'REASONING:' — 1-2 sentences on viability given the budget. "
        "Line 2 starting with 'FOCUS:' — one concrete suggested area to focus on first. "
        "No markdown, no extra text."
    )
    user_msg = (
        f"Idea: {req.idea}\nBudget: ₦{req.budget_naira:,.0f}\n"
        f"Skills: {', '.join(req.user_skills) or 'none listed'}"
    )

    reply = await call_claude(system, [{"role": "user", "content": user_msg}])

    if reply:
        reasoning, focus = "", ""
        for line in reply.splitlines():
            if line.strip().upper().startswith("REASONING:"):
                reasoning = line.split(":", 1)[1].strip()
            elif line.strip().upper().startswith("FOCUS:"):
                focus = line.split(":", 1)[1].strip()
        if reasoning:
            return BusinessRecommendResponse(
                viability_score=score,
                reasoning=reasoning,
                suggested_focus=focus or "Validate demand with 5 potential customers before spending the full budget.",
            )

    # Rule-based fallback (no API key configured, or parsing failed)
    reasoning = (
        f"With ₦{req.budget_naira:,.0f} and {len(req.user_skills)} relevant skill(s) listed, "
        f"this idea has {'strong' if score >= 70 else 'moderate' if score >= 45 else 'limited'} "
        f"initial viability. (Fallback estimate — connect ANTHROPIC_API_KEY for reasoning "
        f"tailored to this specific idea.)"
    )
    suggested_focus = "Start with a small pilot batch or client to validate pricing before scaling."

    return BusinessRecommendResponse(
        viability_score=score,
        reasoning=reasoning,
        suggested_focus=suggested_focus,
    )
