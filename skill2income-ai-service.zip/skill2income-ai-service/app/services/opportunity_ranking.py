"""
Opportunity Ranking — ranks jobs/grants/scholarships/NYSC/government programs
by TF-IDF cosine similarity to a free-text user profile summary. Same
embedding approach as job_matching.py, reused here for consistency.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.models.schemas import RecommendOpportunitiesRequest, OpportunityMatch


def _opportunity_text(o) -> str:
    return f"{o.title} {o.type} {o.eligibility}"


def rank_opportunities(req: RecommendOpportunitiesRequest) -> list[OpportunityMatch]:
    if not req.opportunities:
        return []

    corpus = [req.user_profile_text] + [_opportunity_text(o) for o in req.opportunities]
    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf = vectorizer.fit_transform(corpus)
    similarities = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()

    results = []
    for o, sim in zip(req.opportunities, similarities):
        score = round(max(5, min(99, sim * 100 + 20)))  # +20 floor so plausible matches don't read as near-zero
        reason = (
            f"Relevant to your profile based on overlap with '{o.type}' eligibility "
            f"criteria and stated goals."
            if sim > 0.05
            else f"Loosely related — worth a look if you're open to {o.type} opportunities."
        )
        results.append(
            OpportunityMatch(
                opportunity_id=o.id,
                title=o.title,
                relevance_score=score,
                reason=reason,
            )
        )

    results.sort(key=lambda r: r.relevance_score, reverse=True)
    return results[: req.top_k]
