"""
Income Prediction — a genuinely trained (not hand-coded) scikit-learn
LinearRegression model, trained at service startup on the synthetic dataset
in app/data/synthetic_income_data.py.

Linear regression is used deliberately instead of a more complex model: its
coefficients are directly interpretable, which is what powers the
"explanation"/Explainable-AI part of the response (each feature's exact
naira contribution to the prediction, not just a final number).
"""

from sklearn.linear_model import LinearRegression
import numpy as np

from app.data.synthetic_income_data import generate_synthetic_dataset, FEATURE_NAMES
from app.models.schemas import IncomePredictRequest, IncomePredictResponse

EDUCATION_SCORE_MAP = {
    "none": 20, "primary": 30, "secondary": 50,
    "nce_ond": 65, "bsc_hnd": 80, "msc_plus": 95,
}
INTERNET_SCORE_MAP = {"none": 15, "limited": 50, "stable": 90}
NETWORK_SCORE_MAP = {"small": 30, "medium": 60, "large": 90}

FEATURE_LABELS = {
    "education_score": "Education level",
    "digital_skills_count": "Digital skills",
    "experience_years": "Years of experience",
    "portfolio_items": "Portfolio items",
    "internet_score": "Internet access",
    "network_score": "Professional network",
}

# Train once at import time — this module is imported a single time per
# process by FastAPI, so the model is trained once at service startup.
_X_train, _y_train = generate_synthetic_dataset()
_model = LinearRegression()
_model.fit(_X_train, _y_train)


def _encode(req: IncomePredictRequest) -> np.ndarray:
    return np.array([[
        EDUCATION_SCORE_MAP.get(req.education_level, 50),
        req.digital_skills_count,
        req.experience_years,
        req.portfolio_items,
        INTERNET_SCORE_MAP.get(req.internet_access, 50),
        NETWORK_SCORE_MAP.get(req.network_size, 30),
    ]])


def predict_income(req: IncomePredictRequest) -> IncomePredictResponse:
    x = _encode(req)
    predicted = float(_model.predict(x)[0])
    predicted = max(10000, predicted)

    # Per-feature contribution = coefficient * feature value (linear model,
    # so this decomposition is exact, not an approximation).
    contributions = []
    for name, coef, value in zip(FEATURE_NAMES, _model.coef_, x[0]):
        contributions.append({
            "factor": FEATURE_LABELS.get(name, name),
            "contribution_naira": round(float(coef) * float(value)),
        })
    contributions.sort(key=lambda c: c["contribution_naira"], reverse=True)

    top_factor = contributions[0]["factor"] if contributions else "your profile"
    explanation = (
        f"Estimated from a regression model trained on typical Nigerian income "
        f"patterns across education, experience, digital skills, portfolio, "
        f"connectivity, and network size. {top_factor} is currently your biggest "
        f"positive contributor. This is a statistical estimate, not a guarantee — "
        f"actual offers vary by employer, sector, and location."
    )

    return IncomePredictResponse(
        predicted_monthly_income=round(predicted),
        income_range_low=round(predicted * 0.8),
        income_range_high=round(predicted * 1.25),
        top_factors=contributions,
        explanation=explanation,
    )
