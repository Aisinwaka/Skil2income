"""
Thin wrapper around the Anthropic Messages API. Used by services/chat.py to
generate the AI Mentor's reply after RAG retrieval has selected relevant
knowledge-base context. Falls back to a template response if no API key is
configured, so the service is fully runnable without external credentials.
"""

import os
import httpx

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = "claude-sonnet-4-5"
API_URL = "https://api.anthropic.com/v1/messages"

LANGUAGE_NAMES = {"en": "English", "ha": "Hausa", "yo": "Yoruba", "ig": "Igbo"}


async def call_claude(system: str, messages: list[dict]) -> str | None:
    if not ANTHROPIC_API_KEY:
        return None

    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            resp = await client.post(
                API_URL,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                },
                json={
                    "model": MODEL,
                    "max_tokens": 500,
                    "system": system,
                    "messages": messages,
                },
            )
            if resp.status_code != 200:
                print(f"[ai_client] Anthropic API error {resp.status_code}: {resp.text}")
                return None
            data = resp.json()
            for block in data.get("content", []):
                if block.get("type") == "text":
                    return block.get("text")
            return None
    except Exception as exc:  # network error, timeout, etc.
        print(f"[ai_client] request failed: {exc}")
        return None
