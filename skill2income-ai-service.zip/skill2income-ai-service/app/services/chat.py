"""
Conversational AI (AI Mentor) with Retrieval-Augmented Generation.

Pipeline:
1. Embed the knowledge base (app/data/knowledge_base.json) and the incoming
   message with TF-IDF.
2. Retrieve the top-k most relevant knowledge base entries by cosine similarity.
3. Pass those snippets to Claude as grounding context, alongside conversation
   history, so answers are consistent with Skill2Income's own guidance rather
   than the model's unguided priors.
4. If no ANTHROPIC_API_KEY is configured, fall back to surfacing the
   retrieved snippet directly — still useful, just not conversationally
   phrased.
"""

import json
import os

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.models.schemas import ChatRequest, ChatResponse
from app.services.ai_client import call_claude, LANGUAGE_NAMES

_KB_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base.json")
with open(_KB_PATH, "r") as f:
    _KNOWLEDGE_BASE = json.load(f)

_KB_TEXTS = [entry["text"] for entry in _KNOWLEDGE_BASE]
_VECTORIZER = TfidfVectorizer(stop_words="english")
_KB_MATRIX = _VECTORIZER.fit_transform(_KB_TEXTS)


def _retrieve(query: str, top_k: int = 2) -> list[str]:
    query_vec = _VECTORIZER.transform([query])
    similarities = cosine_similarity(query_vec, _KB_MATRIX).flatten()
    ranked_idx = similarities.argsort()[::-1]
    return [_KB_TEXTS[i] for i in ranked_idx[:top_k] if similarities[i] > 0.03]


async def generate_reply(req: ChatRequest) -> ChatResponse:
    retrieved = _retrieve(req.message)
    lang_name = LANGUAGE_NAMES.get(req.language, "English")

    context_block = "\n".join(f"- {snippet}" for snippet in retrieved) or "(no specific matching guidance found)"
    system = (
        f"You are the AI Mentor inside Skill2Income, an economic mobility platform "
        f"for Nigerians. Reply in {lang_name}. Be warm, direct, practical. "
        f"Ground your answer in this guidance where relevant:\n{context_block}\n"
        f"Keep replies under 100 words unless asked for more detail."
    )

    messages = [{"role": m.role, "content": m.content} for m in req.history if m.role in ("user", "assistant")]
    if not messages or messages[-1]["content"] != req.message:
        messages = messages + [{"role": "user", "content": req.message}]

    reply = await call_claude(system, messages)

    if not reply:
        if retrieved:
            reply = (
                "Here's something relevant: " + retrieved[0] +
                " (Connect ANTHROPIC_API_KEY for a fully conversational reply.)"
            )
        else:
            reply = (
                "Thanks for sharing that — I don't have specific guidance on this yet. "
                "Try breaking it into one concrete next step. "
                "(Connect ANTHROPIC_API_KEY for full AI-powered coaching.)"
            )

    return ChatResponse(reply=reply, retrieved_context=retrieved)
