"""
Skill Gap Detection — compares a user's current skills against the skills
required for a target role, with a 0-100 gap score (higher = bigger gap) and
concrete, prioritized learning recommendations.
"""

from app.models.schemas import SkillGapRequest, SkillGapResponse


def analyze_skill_gap(req: SkillGapRequest) -> SkillGapResponse:
    user_skills = {s.lower().strip() for s in req.user_skills}
    target_skills = {s.lower().strip() for s in req.target_skills}

    matched = sorted(user_skills & target_skills)
    missing = sorted(target_skills - user_skills)

    gap_score = round(len(missing) / len(target_skills) * 100) if target_skills else 0

    if not missing:
        recommendation = (
            f"You already have every skill listed for {req.target_role}. "
            f"Focus next on portfolio proof and applying."
        )
    elif gap_score <= 30:
        recommendation = (
            f"You're close — pick up {', '.join(missing)} first; a short course or "
            f"two should close most of the gap for {req.target_role}."
        )
    elif gap_score <= 60:
        recommendation = (
            f"Moderate gap for {req.target_role}. Prioritize {missing[0]} first "
            f"(most commonly required), then {', '.join(missing[1:]) or 'the remaining skills'}."
        )
    else:
        recommendation = (
            f"Significant gap for {req.target_role}. Consider a structured learning "
            f"path covering {', '.join(missing[:3])} before applying, or look at "
            f"adjacent roles that better match your current skills: {', '.join(sorted(user_skills)) or 'none listed yet'}."
        )

    return SkillGapResponse(
        target_role=req.target_role,
        matched_skills=matched,
        missing_skills=missing,
        gap_score=gap_score,
        recommendation=recommendation,
    )
