from pydantic import BaseModel, Field
from typing import Literal, Optional


class JobIn(BaseModel):
    id: str
    title: str
    description: str = ""
    skills_required: list[str] = []


class MatchJobsRequest(BaseModel):
    user_skills: list[str]
    user_goals: str = ""
    jobs: list[JobIn]
    top_k: int = 10


class JobMatchResult(BaseModel):
    job_id: str
    title: str
    match_score: int  # 0-100
    matched_skills: list[str]
    missing_skills: list[str]
    explanation: str


class MatchJobsResponse(BaseModel):
    results: list[JobMatchResult]


class SkillGapRequest(BaseModel):
    user_skills: list[str]
    target_role: str
    target_skills: list[str]


class SkillGapResponse(BaseModel):
    target_role: str
    matched_skills: list[str]
    missing_skills: list[str]
    gap_score: int  # 0-100, higher = bigger gap
    recommendation: str


EducationLevel = Literal["none", "primary", "secondary", "nce_ond", "bsc_hnd", "msc_plus"]
InternetAccess = Literal["none", "limited", "stable"]
NetworkSize = Literal["small", "medium", "large"]


class IncomePredictRequest(BaseModel):
    education_level: EducationLevel = "secondary"
    digital_skills_count: int = Field(0, ge=0)
    experience_years: float = Field(0, ge=0)
    portfolio_items: int = Field(0, ge=0)
    internet_access: InternetAccess = "limited"
    network_size: NetworkSize = "small"


class IncomePredictResponse(BaseModel):
    predicted_monthly_income: int
    income_range_low: int
    income_range_high: int
    top_factors: list[dict]  # [{factor, contribution_naira}]
    explanation: str


class OpportunityIn(BaseModel):
    id: str
    title: str
    type: str
    eligibility: str = ""


class RecommendOpportunitiesRequest(BaseModel):
    user_profile_text: str
    opportunities: list[OpportunityIn]
    top_k: int = 5


class OpportunityMatch(BaseModel):
    opportunity_id: str
    title: str
    relevance_score: int
    reason: str


class RecommendOpportunitiesResponse(BaseModel):
    results: list[OpportunityMatch]


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    message: str
    language: Literal["en", "ha", "yo", "ig"] = "en"
    history: list[ChatMessage] = []


class ChatResponse(BaseModel):
    reply: str
    retrieved_context: list[str]  # knowledge base snippets used (for transparency)


class BusinessRecommendRequest(BaseModel):
    idea: str
    budget_naira: float = Field(gt=0)
    user_skills: list[str] = []


class BusinessRecommendResponse(BaseModel):
    viability_score: int  # 0-100
    reasoning: str
    suggested_focus: str
