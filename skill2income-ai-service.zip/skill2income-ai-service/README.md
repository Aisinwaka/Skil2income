# Skill2Income — AI Service

Phase 5 deliverable: a real, working Python/FastAPI microservice implementing
the AI models from the master spec — Career Recommendation, Skill Gap
Detection, Income Prediction, Opportunity Ranking, Business Recommendation,
and Conversational AI (RAG) — each backed by genuine techniques (TF-IDF
embeddings, a trained scikit-learn regression model, retrieval-augmented
generation), not hand-waved responses.

## Honest scope note

The master spec's AI stack lists LangChain, Llama models, and Sentence
Transformers. This implementation deliberately uses lighter, fully-offline
equivalents instead:

- **TF-IDF + cosine similarity** (scikit-learn) instead of sentence-transformer
  embeddings, for job matching, opportunity ranking, and RAG retrieval. This
  needs no downloaded model weights or GPU, runs instantly, and is a real,
  standard information-retrieval technique — just keyword/n-gram based
  rather than deep semantic understanding. It will occasionally miss a
  paraphrase (e.g. "applied to jobs" vs. "job applications" without
  stemming). Swap in real sentence embeddings later — every service function
  has a single `_vectorize`/`TfidfVectorizer` call to replace; the ranking
  and explanation logic around it is unchanged.
- **Direct Anthropic API calls** (via `httpx`) instead of LangChain. For a
  single-provider integration like this, LangChain adds an abstraction layer
  without much benefit — the raw API call is simpler to read, debug, and
  keep dependency-light.
- **A real trained scikit-learn `LinearRegression`** for income prediction,
  not a mock. It's trained at service startup on a documented synthetic
  dataset (see below) since no real historical income data exists yet.
  Linear regression is used deliberately over a more complex model because
  its coefficients are directly, exactly interpretable — that's what powers
  the explainability in the response.

## Deploying

`Dockerfile`, `railway.json`, and `render.yaml` are included — see the
top-level `DEPLOYMENT.md` (shipped alongside this project) for exact
commands. This service is stateless (no database), so it also works fine on
most serverless container platforms if you'd rather use something else.

## Testing

```bash
pip install -r requirements.txt   # includes pytest, pytest-asyncio, pytest-cov
pytest -v                          # run once, verbose
pytest --cov=app --cov-report=term-missing   # with coverage report
```

25 tests across 5 files (pytest + FastAPI `TestClient`), covering every
endpoint: job matching (ranking order, skill overlap, `top_k`, empty input,
validation), skill gap detection (no gap / partial / full gap, case
insensitivity), income prediction (shape, monotonicity per feature, floor
clamping, validation), opportunity ranking, and chat + business
recommendation fallback paths (since no `ANTHROPIC_API_KEY` is set in the
test environment). Coverage is ~92% statements; the main gap is the
real-API-key branch in `ai_client.py`, which needs live credentials to
exercise.

Writing these tests caught a real bug: `ChatRequest.history` was typed as
`list[dict]` while `chat.py` accessed it with attribute syntax (`m.role`,
`m.content`), which would have raised at runtime on the first real chat
request. Fixed by making `ChatMessage` a proper Pydantic model — also
tightened `IncomePredictRequest` and `ChatRequest` to use `Literal` types
instead of unvalidated strings, so invalid values now fail fast with a
clear 422 instead of silently falling back to a default.

## Getting started

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # optionally add your ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for interactive Swagger docs (auto-generated
by FastAPI from the Pydantic schemas).

Without `ANTHROPIC_API_KEY` set, `/chat` and `/business/recommend` still
return useful, clearly-labeled fallback responses instead of erroring — the
service is fully runnable with zero external credentials.

## Endpoints

| Method | Route                  | Powers | Technique |
|--------|------------------------|--------|-----------|
| POST | `/match/jobs`            | Career Recommendation / Job Matching | TF-IDF cosine similarity + explicit skill-overlap, blended and explained |
| POST | `/skill-gap`               | Skill Gap Detection | Set difference against target role skills, prioritized recommendation |
| POST | `/income/predict`           | Income Prediction | Trained `LinearRegression`, exact per-feature naira contributions |
| POST | `/opportunities/rank`        | Opportunity Ranking | TF-IDF relevance ranking of jobs/grants/scholarships/NYSC/gov programs |
| POST | `/business/recommend`         | Business Recommendation | Heuristic viability score + Claude-generated reasoning (with fallback) |
| POST | `/chat`                         | Conversational AI | RAG: TF-IDF retrieval over `data/knowledge_base.json` + Claude generation |
| GET  | `/health`                         | — | Reports whether an AI model (Anthropic key) is configured |

Full request/response shapes are in `app/models/schemas.py` and enforced by
Pydantic — invalid requests get a clear 422 with field-level errors.

## Project structure

```
app/
  main.py                  FastAPI app, route wiring
  models/schemas.py          Pydantic request/response models
  services/
    job_matching.py            TF-IDF job matching
    skill_gap.py                 Skill gap analysis
    income_prediction.py          Trained regression model + explainability
    opportunity_ranking.py          TF-IDF opportunity ranking
    business_recommend.py            Viability scoring + AI reasoning
    chat.py                            RAG pipeline
    ai_client.py                        Anthropic API wrapper + fallback
  data/
    knowledge_base.json         RAG knowledge base (job search, pricing, NYSC, etc.)
    synthetic_income_data.py      Documented synthetic training data generator
```

## The income prediction training data

There's no real historical income dataset yet — the platform hasn't
launched. `app/data/synthetic_income_data.py` generates a synthetic dataset
with documented, plausible feature-to-income relationships (education,
experience, digital skills, portfolio, connectivity, network size), so the
model has real signal to learn from and produces sensible, explainable
predictions today.

**Once real user data exists** (from `POST /assessment` submissions on the
backend joined with self-reported income in FinanceAI), retrain on that
instead by replacing `generate_synthetic_dataset()`'s output with a real
`X, y` array — the rest of `income_prediction.py` (encoding, prediction,
explanation) doesn't need to change.

## RAG knowledge base

`app/data/knowledge_base.json` currently holds 10 short, Nigeria-specific
coaching facts (job search norms, freelance pricing, NYSC SAED, CAC
registration, etc.). This is intentionally small and hand-curated for this
phase. To grow it: add more entries with the same `{id, topic, text}` shape —
no code changes needed, since the vectorizer is rebuilt from whatever's in
the file at service startup.

## Known limitations

- TF-IDF has no stemming or synonym awareness, so it can miss paraphrases
  (see scope note above). Good enough for keyword-adjacent matching; not
  true semantic search.
- The income model is trained on synthetic, not real, data — treat
  predictions as illustrative until retrained on real submissions.
- No caching layer — every request re-runs TF-IDF fit/transform. Fine at
  current scale; add a precomputed job/opportunity embedding cache if the
  jobs/opportunities lists grow past a few thousand rows.

## Next steps (Phase 6+)

- Have the Node backend (Phase 4) call this service for `/jobs`, `/chat`,
  `/business/generate`, and dashboard recommendations instead of doing that
  logic inline — this service is designed to be called from there.
- Add a vector database (pgvector, Qdrant, etc.) once the jobs/opportunities
  corpus is too large for in-memory TF-IDF.
- Retrain `income_prediction.py` on real user data once available.
